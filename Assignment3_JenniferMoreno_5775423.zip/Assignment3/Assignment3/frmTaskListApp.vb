﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/28/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Imports System.IO

Public Class frmTaskListApp

    'dimension file variables
    Public objWriteFile As StreamWriter
    Public objReadFile As StreamReader

    Private Sub frmTaskListApp_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCreateFile_Click(sender As Object, e As EventArgs) Handles btnCreateFile.Click
        blnCreateFlag = True

        Dim strFileName As String = ""
        strFileName = txtFileName.Text

        If strFileName <> String.Empty Then
            'add FileName to listbox
            lstTaskFiles.Items.Add(strFileName)

            'Use StreamWriter to create a file
            objWriteFile = File.CreateText(strFileName)

            'Open Task Details form for entry of task information
            frmTaskDetails.ShowDialog()
        End If
    End Sub

    Private Sub btnOpenFile_Click(sender As Object, e As EventArgs) Handles btnOpenFile.Click
        blnOpenFlag = True

        Dim strFileName As String = ""
        Dim objDialog As DialogResult

        'Use OpenFileDialog control to allow user to select file name
        dlgOpenFileDialog.Filter = "txt Files (Text Files)|*.txt"
        objDialog = dlgOpenFileDialog.ShowDialog
        If objDialog = Windows.Forms.DialogResult.OK Then
            strFileName = dlgOpenFileDialog.FileName
        Else
            blnOpenFlag = False
        End If

        'populate FileName textbox with selected filename
        txtFileName.Text = strFileName

        'add FileName to listbox
        lstTaskFiles.Items.Add(strFileName)

        'Use StreamReader to open file
        objReadFile = File.OpenText(strFileName)

        'loop until end of file using ReadLine() to populate Details listbox
        Dim strInfo As String
        Do Until objReadFile.EndOfStream
            strInfo = objReadFile.ReadLine()

            frmTaskDetails.lstTaskDetails.Items.Add(strInfo)
        Loop

        'Show Details form to display a list of task information
        frmTaskDetails.ShowDialog()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        If blnCreateFlag Then
            objWriteFile.Close()
        ElseIf blnOpenFlag Then
            objReadFile.Close()
        End If

        Me.Close()
    End Sub

    Private Sub frmTaskListApp_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated

    End Sub
End Class
