﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/28/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Imports System.IO

Public Class frmTaskDetails

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'add Name, Date, Time, Complete, and Category values
        ' to Details listbox using TaskInfo structure

        If txtTask.Text <> String.Empty And txtTime.Text <> String.Empty Then

            Dim lstTask As New List(Of Task)
            Dim stTask As Task
            With stTask
                .strName = CStr(txtTask.Text)
                .dtDate = datDateTimePicker.Value
                .dtTime = txtTime.Text.ToString
                .blnComplete = chkComplete.Checked
                .strCategory = lblColor.ForeColor.ToString
            End With

            lstTaskDetails.Items.Add(stTask)

            'clear values from Textboxes
            txtTask.Text = String.Empty
            txtTime.Text = String.Empty
            datDateTimePicker.ResetText()

            'clear values from label
            lblColor.ForeColor = Color.Black
            lblColor.Text = "Color[]"

            'uncheck Complete
            chkComplete.CheckState = CheckState.Unchecked

            'Enable save and cancel buttons only if Create File was clicked on initial form
            ' AND Details listbox is not empty
            If blnCreateFlag And lstTaskDetails.Items.Count > 0 Then
                btnSave.Enabled = True
                btnCancel.Enabled = True
            End If

        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        Dim intIndex As Integer

        'remove selected item in Details listbox
        intIndex = lstTaskDetails.SelectedIndex
        If intIndex <> -1 Then
            lstTaskDetails.Items.RemoveAt(intIndex)
        Else
            MessageBox.Show("No task item selected.", "Error")
        End If

        'Enable save and cancel buttons only if Create File was clicked on initial form
        ' AND Details listbox is not empty
        If blnCreateFlag And lstTaskDetails.Items.Count > 0 Then
            btnSave.Enabled = True
            btnCancel.Enabled = True
        End If
    End Sub

    Private Sub btnColor_Click(sender As Object, e As EventArgs) Handles btnColor.Click

        'Use color dialog to populate category label and font color
        If dlgColorDialog.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            lblColor.ForeColor = dlgColorDialog.Color
            lblColor.Text = lblColor.ForeColor.ToString
        End If

        'Enable save and cancel buttons only if Create File was clicked on initial form
        ' AND Details listbox is not empty
        If blnCreateFlag And lstTaskDetails.Items.Count > 0 Then
            btnSave.Enabled = True
            btnCancel.Enabled = True
        End If
    End Sub

    Private Sub lstTaskDetails_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstTaskDetails.SelectedIndexChanged

        Dim intIndex As Integer
        Dim stTask As Task

        'using selected item in Details listbox... populate Task, Date, Time,
        ' Complete, and Category fields
        intIndex = lstTaskDetails.SelectedIndex

        If intIndex <> -1 Then
            stTask = lstTaskDetails.Items.Item(intIndex)

            txtTask.Text = stTask.strName
            datDateTimePicker.Value = stTask.dtDate
            txtTime.Text = stTask.dtTime

            If stTask.blnComplete Then
                chkComplete.CheckState = CheckState.Checked
            Else
                chkComplete.CheckState = CheckState.Unchecked
            End If


            lblColor.ForeColor = Color.FromName(stTask.strCategory)
            lblColor.Text = lblColor.ForeColor.ToString
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        'Use StreamWriter to loop through Details items and
        ' Write() write each record to file
        For Each stItem As Task In lstTaskDetails.Items
            frmTaskListApp.objWriteFile.WriteLine(stItem)
        Next

        'Close/hide form
        Me.Close()

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        'First prompt user YES/NO?
        Dim dlgResult As DialogResult = MessageBox.Show("Pending changes, sure you want to cancel?", "Confirmation", MessageBoxButtons.YesNo)

        'For YES do not save to file, then close/hide Details form
        If (dlgResult = DialogResult.Yes) Then
            Me.Close()

            'For NO do not save to file, but stay on Details form.
        End If
    End Sub

    Private Sub frmTaskDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Enable save and cancel buttons only if Create File was clicked on initial form
        ' AND Details listbox is not empty
        If blnCreateFlag And lstTaskDetails.Items.Count > 0 Then
            btnSave.Enabled = True
            btnCancel.Enabled = True
        End If
    End Sub
End Class