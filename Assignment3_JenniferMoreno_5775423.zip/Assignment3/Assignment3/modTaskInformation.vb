﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/28/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Module modTaskInformation

    'Structure definition for task information
    Public Structure Task
        Public strName As String
        Public dtDate As Date
        Public dtTime As Date
        Public blnComplete As Boolean
        Public strCategory As String

        Public Overrides Function ToString() As String
            Return strName + ", " + CStr(dtDate) + ", " + CStr(dtTime) + ", " + CStr(blnComplete) + ", " + strCategory
        End Function


    End Structure

    'Global flags for checking which button was pressed on the initial form
    Public blnCreateFlag As Boolean = False
    Public blnOpenFlag As Boolean = False
End Module
