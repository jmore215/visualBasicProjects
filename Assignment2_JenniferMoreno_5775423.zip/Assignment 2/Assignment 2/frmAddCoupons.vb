﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/14/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Public Class frmAddCoupons
    Private Sub btnAddCoupons_Click(sender As Object, e As EventArgs) Handles btnAddCoupons.Click

        'Store selected item name and price
        If lstCoupons.SelectedIndex = -1 Then
            MessageBox.Show("No item has been selected to add.", "Error")
        ElseIf lstCoupons.SelectedIndex = 0 Then
            frmShopList.lstShoppingList.Items.Add("Milk (COUPON)")
            Me.Close()
        ElseIf lstCoupons.SelectedIndex = 1 Then
            frmShopList.lstShoppingList.Items.Add("Sugar (COUPON)")
            Me.Close()
        ElseIf lstCoupons.SelectedIndex = 2 Then
            frmShopList.lstShoppingList.Items.Add("Coffee (COUPON)")
            Me.Close()
        End If
    End Sub

    Private Sub btnCloseCoupons_Click(sender As Object, e As EventArgs) Handles btnCloseCoupons.Click
        Me.Close()
    End Sub
End Class