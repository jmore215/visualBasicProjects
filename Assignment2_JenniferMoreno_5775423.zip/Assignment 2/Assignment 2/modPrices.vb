﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/14/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Module modPrices
    'Global variable for price of currently selected item
    Public dblPrice As Double
    'Global variable for name of currently selected item
    Public strName As String

    'Sales tax
    Public dblSalesTax As Double = 0.06
    'Shipping rate
    Public dblShippingRate As Double = 2.0

    'Name and prices of the available PRODUCTS:
    Public dblBreadPRODUCT As Double = 3.95
    Public dblMilkPRODUCT As Double = 4.5
    Public dblSugarPRODUCT As Double = 2.5
    Public dblCoffeePRODUCT As Double = 4.95

    'Name and credit of the available COUPONS:
    Public dblMilkCOUPON As Double = -0.75
    Public dblSugarCOUPON As Double = -0.55
    Public dblCoffeeCOUPON As Double = -1.85

    'Global variables for calculation in frmShopList
    Public dblProductSum As Double = 0.0
    Public dblCouponSum As Double = 0.0
    Public dblTax As Double = 0.0
    Public dblShippingSum As Double = 0.0


    Public Sub Products()
        'reset global sum of products
        dblProductSum = 0.0

        'loop through each item in the list and add corresponding product prices to sum
        For Each strItem As String In frmShopList.lstShoppingList.Items
            Select Case strItem
                Case "Bread (PRODUCT)"
                    dblProductSum += dblBreadPRODUCT
                Case "Milk (PRODUCT)"
                    dblProductSum += dblMilkPRODUCT
                Case "Sugar (PRODUCT)"
                    dblProductSum += dblSugarPRODUCT
                Case "Coffee (PRODUCT)"
                    dblProductSum += dblCoffeePRODUCT
            End Select
        Next

        'place formatted value into appropriate label in the frmShopList
        frmShopList.lblProducts.Text = dblProductSum.ToString("c")
    End Sub

    Public Sub Coupons()
        'reset global sum of coupons
        dblCouponSum = 0.0

        'loop through each item in the list and add corresponding coupon discounts to sum
        For Each strItem As String In frmShopList.lstShoppingList.Items
            Select Case strItem
                Case "Milk (COUPON)"
                    dblCouponSum += dblMilkCOUPON
                Case "Sugar (COUPON)"
                    dblCouponSum += dblSugarCOUPON
                Case "Coffee (COUPON)"
                    dblCouponSum += dblCoffeeCOUPON
            End Select
        Next

        'place formatted value into appropriate label in the frmShopList
        dblCouponSum *= -1
        frmShopList.lblCoupons.Text = "(" + dblCouponSum.ToString("c") + ")"
        'make value negative again so it can be used properly in total method
        dblCouponSum *= -1
    End Sub

    Public Sub Tax(ByRef dblPSum As Double, ByRef dblCSum As Double)
        'reset global tax value
        dblTax = 0.0

        'calculate tax amount by multiplying Product Sum by tax rate
        dblTax = dblPSum * dblSalesTax

        'place formatted value into appropriate label in the frmShopList
        frmShopList.lblTax.Text = dblTax.ToString("c")
    End Sub

    Public Sub Shipping()
        'Reset shipping sum to 0
        dblShippingSum = 0.0

        'if the checkbox is checked
        If frmShopList.chkDelivery.Checked Then
            'then calculate shipping rate according to how many products there are
            For Each strItem As String In frmShopList.lstShoppingList.Items
                If strItem.Contains("(PRODUCT)") Then
                    dblShippingSum += dblShippingRate
                End If
            Next
        End If

        'place formatted value into appropriate label in the frmShopList
        frmShopList.lblShipping.Text = dblShippingSum.ToString("c")
    End Sub

    Public Sub Total(ByRef dblPSum As Double, ByRef dblCSum As Double, ByRef dblTax As Double, ByRef dblSSum As Double)
        'default the total value to 0
        Dim dblTotal As Double = 0.0

        'calculate total
        dblTotal = dblPSum + dblCSum + dblTax + dblSSum

        'place formatted value into appropriate label in the frmShopList
        frmShopList.lblTotal.Text = dblTotal.ToString("c")
    End Sub

End Module
