﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBuyProducts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBuyProducts))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lstProducts = New System.Windows.Forms.ListBox()
        Me.btnAddProducts = New System.Windows.Forms.Button()
        Me.btnCloseProducts = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstProducts)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(331, 145)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select an item"
        '
        'lstProducts
        '
        Me.lstProducts.FormattingEnabled = True
        Me.lstProducts.Items.AddRange(New Object() {"Bread (PRODUCT)", "Milk (PRODUCT)", "Sugar (PRODUCT)", "Coffee (PRODUCT)"})
        Me.lstProducts.Location = New System.Drawing.Point(6, 19)
        Me.lstProducts.Name = "lstProducts"
        Me.lstProducts.Size = New System.Drawing.Size(291, 108)
        Me.lstProducts.TabIndex = 0
        '
        'btnAddProducts
        '
        Me.btnAddProducts.Location = New System.Drawing.Point(64, 163)
        Me.btnAddProducts.Name = "btnAddProducts"
        Me.btnAddProducts.Size = New System.Drawing.Size(112, 39)
        Me.btnAddProducts.TabIndex = 1
        Me.btnAddProducts.Text = "Add to List"
        Me.btnAddProducts.UseVisualStyleBackColor = True
        '
        'btnCloseProducts
        '
        Me.btnCloseProducts.Location = New System.Drawing.Point(195, 163)
        Me.btnCloseProducts.Name = "btnCloseProducts"
        Me.btnCloseProducts.Size = New System.Drawing.Size(77, 39)
        Me.btnCloseProducts.TabIndex = 2
        Me.btnCloseProducts.Text = "Close"
        Me.btnCloseProducts.UseVisualStyleBackColor = True
        '
        'frmBuyProducts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(355, 214)
        Me.Controls.Add(Me.btnCloseProducts)
        Me.Controls.Add(Me.btnAddProducts)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBuyProducts"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Buy Products"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lstProducts As ListBox
    Friend WithEvents btnAddProducts As Button
    Friend WithEvents btnCloseProducts As Button
End Class
