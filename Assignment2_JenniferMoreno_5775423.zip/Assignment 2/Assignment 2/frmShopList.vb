﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/14/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Public Class frmShopList

    Private Sub frmShopList_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Clear labels when form loads
        lblProducts.Text = String.Empty
        lblCoupons.Text = String.Empty
        lblTax.Text = String.Empty
        lblShipping.Text = String.Empty
        lblTotal.Text = String.Empty

    End Sub

    Private Sub ResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetToolStripMenuItem.Click
        'Clear the product list
        lstShoppingList.Items.Clear()

        'Clear labels
        lblProducts.Text = String.Empty
        lblCoupons.Text = String.Empty
        lblTax.Text = String.Empty
        lblShipping.Text = String.Empty
        lblTotal.Text = String.Empty
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'Close the application
        Me.Close()
    End Sub

    Private Sub CouponsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CouponsToolStripMenuItem.Click
        'Open the modal coupons form
        frmAddCoupons.ShowDialog()
    End Sub

    Private Sub ProductsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductsToolStripMenuItem.Click
        'Open the modal products form
        frmBuyProducts.ShowDialog()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'Display messagebox with application name and version
        MessageBox.Show("Application Name: Store" & vbNewLine & "Version: 1", "About")
    End Sub

    Private Sub frmShopList_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated

        'Calculate the prices for all labels each time the form is activated
        Products()
        Coupons()
        Tax(dblProductSum, dblCouponSum)
        Shipping()
        Total(dblProductSum, dblCouponSum, dblTax, dblShippingSum)

    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Dim intIndex As Integer

        'Remove selected item from lstShoppingList
        intIndex = lstShoppingList.SelectedIndex
        If intIndex <> -1 Then
            lstShoppingList.Items.RemoveAt(intIndex)

            'Update all totals using updated lstShoppingList 
            Products()
            Coupons()
            Tax(dblProductSum, dblCouponSum)
            Shipping()
            Total(dblProductSum, dblCouponSum, dblTax, dblShippingSum)
        Else
            MessageBox.Show("No item selected.", "Error")
        End If
    End Sub

    Private Sub cboContains_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboContains.SelectedIndexChanged

        Dim blnFoundFlag As Boolean = False

        'loop through product list items to determine if list contains ComboBox.Text
        'if an instance is found, set flag to true
        For Each strItem As String In lstShoppingList.Items
            If strItem.Contains(cboContains.Text) Then
                blnFoundFlag = True
            End If
        Next

        'Show appropriate message based on whether the list contains item or not
        If blnFoundFlag = True Then
            MessageBox.Show("Contains " & cboContains.Text, "Contains?")
        Else
            MessageBox.Show("Does Not Contain " & cboContains.Text, "Contains?")
        End If

    End Sub

    Private Sub chkDelivery_CheckedChanged(sender As Object, e As EventArgs) Handles chkDelivery.CheckedChanged

        'Reset variables in preparation for recalculating
        dblProductSum = 0.0
        dblCouponSum = 0.0
        dblTax = 0.0
        dblShippingSum = 0.0

        'Call all calculation methods each time the check box is checked or unchecked to adjust prices
        Products()
        Coupons()
        Tax(dblProductSum, dblCouponSum)
        Shipping()
        Total(dblProductSum, dblCouponSum, dblTax, dblShippingSum)

    End Sub
End Class