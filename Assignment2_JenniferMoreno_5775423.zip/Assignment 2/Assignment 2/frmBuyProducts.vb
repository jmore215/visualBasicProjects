﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 6/14/2020

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Public Class frmBuyProducts
    Private Sub btnAddProducts_Click(sender As Object, e As EventArgs) Handles btnAddProducts.Click

        'Store selected item name and price
        If lstProducts.SelectedIndex = -1 Then
            MessageBox.Show("No item has been selected to add.", "Error")
        ElseIf lstProducts.SelectedIndex = 0 Then
            frmShopList.lstShoppingList.Items.Add("Bread (PRODUCT)")
            Me.Close()
        ElseIf lstProducts.SelectedIndex = 1 Then
            frmShopList.lstShoppingList.Items.Add("Milk (PRODUCT)")
            Me.Close()
        ElseIf lstProducts.SelectedIndex = 2 Then
            frmShopList.lstShoppingList.Items.Add("Sugar (PRODUCT)")
            Me.Close()
        ElseIf lstProducts.SelectedIndex = 3 Then
            frmShopList.lstShoppingList.Items.Add("Coffee (PRODUCT)")
            Me.Close()
        End If
    End Sub

    Private Sub btnCloseProducts_Click(sender As Object, e As EventArgs) Handles btnCloseProducts.Click
        Me.Close()
    End Sub
End Class