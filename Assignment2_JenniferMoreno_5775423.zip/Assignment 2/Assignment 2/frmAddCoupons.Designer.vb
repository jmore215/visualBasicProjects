﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddCoupons
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddCoupons))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lstCoupons = New System.Windows.Forms.ListBox()
        Me.btnAddCoupons = New System.Windows.Forms.Button()
        Me.btnCloseCoupons = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstCoupons)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(331, 143)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select an item"
        '
        'lstCoupons
        '
        Me.lstCoupons.FormattingEnabled = True
        Me.lstCoupons.Items.AddRange(New Object() {"Milk (COUPON)", "Sugar (COUPON)", "Coffee (COUPON)"})
        Me.lstCoupons.Location = New System.Drawing.Point(16, 19)
        Me.lstCoupons.Name = "lstCoupons"
        Me.lstCoupons.Size = New System.Drawing.Size(298, 108)
        Me.lstCoupons.TabIndex = 0
        '
        'btnAddCoupons
        '
        Me.btnAddCoupons.Location = New System.Drawing.Point(63, 161)
        Me.btnAddCoupons.Name = "btnAddCoupons"
        Me.btnAddCoupons.Size = New System.Drawing.Size(116, 40)
        Me.btnAddCoupons.TabIndex = 1
        Me.btnAddCoupons.Text = "Add to List"
        Me.btnAddCoupons.UseVisualStyleBackColor = True
        '
        'btnCloseCoupons
        '
        Me.btnCloseCoupons.Location = New System.Drawing.Point(200, 161)
        Me.btnCloseCoupons.Name = "btnCloseCoupons"
        Me.btnCloseCoupons.Size = New System.Drawing.Size(76, 40)
        Me.btnCloseCoupons.TabIndex = 2
        Me.btnCloseCoupons.Text = "Close"
        Me.btnCloseCoupons.UseVisualStyleBackColor = True
        '
        'frmAddCoupons
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(356, 213)
        Me.Controls.Add(Me.btnCloseCoupons)
        Me.Controls.Add(Me.btnAddCoupons)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAddCoupons"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Coupons"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lstCoupons As ListBox
    Friend WithEvents btnAddCoupons As Button
    Friend WithEvents btnCloseCoupons As Button
End Class
