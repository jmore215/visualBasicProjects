﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 7/10/20

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.


Imports ContactDO
Public Class frmSearch

    Private mContact As New ContactDO.ContactDO()

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        'Clear search text box and close the form
        txtSearch.Text = String.Empty
        Me.Close()

    End Sub

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click

        Dim intContactIndex As Integer = 0

        'Make sure text is an integer before continuing
        If Integer.TryParse(txtSearch.Text, intContactIndex) Then

            'Make sure the input is not 0
            If CInt(txtSearch.Text) = 0 Then
                MessageBox.Show("Contact ID can't be 0. Contact ID numbers start at 1.")
            Else
                intContactIndex = CInt(txtSearch.Text) - 1

                'Make sure the index is valid before searching
                If intContactIndex > -1 And intContactIndex < mContact.items.Rows.Count Then

                    'Load the Contact Info form with the correct information
                    frmContactInfo.lblContactID.Text = mContact.items().Rows(intContactIndex)("Contact_ID").ToString
                    frmContactInfo.lblFirstName.Text = mContact.items().Rows(intContactIndex)("First_Name").ToString
                    frmContactInfo.lblMiddleName.Text = mContact.items().Rows(intContactIndex)("Middle_Name").ToString
                    frmContactInfo.lblLastName.Text = mContact.items().Rows(intContactIndex)("Last_Name").ToString
                    frmContactInfo.lblType.Text = mContact.items().Rows(intContactIndex)("Type").ToString
                    frmContactInfo.lblTelephone.Text = mContact.items().Rows(intContactIndex)("Telephone").ToString
                    frmContactInfo.lblExtension.Text = mContact.items().Rows(intContactIndex)("Extension").ToString
                    frmContactInfo.lblEmail.Text = mContact.items().Rows(intContactIndex)("Email_Address").ToString

                    'Close the form to display the search result
                    Me.Close()

                Else
                    MessageBox.Show("This Contact ID doesn't exist.")
                End If
            End If
        Else
            MessageBox.Show("Not a valid Contact ID, input must be a whole number.")
        End If

    End Sub
End Class