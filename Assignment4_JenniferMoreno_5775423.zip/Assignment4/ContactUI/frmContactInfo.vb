﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 7/10/20

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.

Imports ContactBO
Imports ContactDO

Public Class frmContactInfo

    Private mContact As New ContactDO.ContactDO()

    Private Sub frmContactInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Make Contact Info initially empty
        lblContactID.Text = String.Empty
        lblFirstName.Text = String.Empty
        lblMiddleName.Text = String.Empty
        lblLastName.Text = String.Empty
        lblType.Text = String.Empty
        lblTelephone.Text = String.Empty
        lblExtension.Text = String.Empty
        lblEmail.Text = String.Empty

        'Load the Contact table with default first record
        If mContact.Insert(1, "William", "Henry", "Gates", "Work", "(206) 709-3400", "x3", "billg@microsoft.com") Then
        End If

    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click

        'Display the first contact record from the Contact table
        'Instantiate data object in the data layer
        'Open the database using ADO.Net and TableAdapter

        'Set screen values based on the Datasource
        lblContactID.Text = mContact.items().Rows(0)("Contact_ID").ToString
        lblFirstName.Text = mContact.items().Rows(0)("First_Name").ToString
        lblMiddleName.Text = mContact.items().Rows(0)("Middle_Name").ToString
        lblLastName.Text = mContact.items().Rows(0)("Last_Name").ToString
        lblType.Text = mContact.items().Rows(0)("Type").ToString
        lblTelephone.Text = mContact.items().Rows(0)("Telephone").ToString
        lblExtension.Text = mContact.items().Rows(0)("Extension").ToString
        lblEmail.Text = mContact.items().Rows(0)("Email_Address").ToString
    End Sub

    Private Sub btnNextRecord_Click(sender As Object, e As EventArgs) Handles btnNextRecord.Click

        Dim intIndex As Integer = mContact.GetNext()

        'Display the next record
        lblContactID.Text = mContact.items().Rows(intIndex)("Contact_ID").ToString
        lblFirstName.Text = mContact.items().Rows(intIndex)("First_Name").ToString
        lblMiddleName.Text = mContact.items().Rows(intIndex)("Middle_Name").ToString
        lblLastName.Text = mContact.items().Rows(intIndex)("Last_Name").ToString
        lblType.Text = mContact.items().Rows(intIndex)("Type").ToString
        lblTelephone.Text = mContact.items().Rows(intIndex)("Telephone").ToString
        lblExtension.Text = mContact.items().Rows(intIndex)("Extension").ToString
        lblEmail.Text = mContact.items().Rows(intIndex)("Email_Address").ToString

    End Sub

    Private Sub btnPreviousRecord_Click(sender As Object, e As EventArgs) Handles btnPreviousRecord.Click

        Dim intIndex As Integer = mContact.GetPrev()

        'Display the previous record
        lblContactID.Text = mContact.items().Rows(intIndex)("Contact_ID").ToString
        lblFirstName.Text = mContact.items().Rows(intIndex)("First_Name").ToString
        lblMiddleName.Text = mContact.items().Rows(intIndex)("Middle_Name").ToString
        lblLastName.Text = mContact.items().Rows(intIndex)("Last_Name").ToString
        lblType.Text = mContact.items().Rows(intIndex)("Type").ToString
        lblTelephone.Text = mContact.items().Rows(intIndex)("Telephone").ToString
        lblExtension.Text = mContact.items().Rows(intIndex)("Extension").ToString
        lblEmail.Text = mContact.items().Rows(intIndex)("Email_Address").ToString

    End Sub

    Private Sub ExitToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem1.Click

        'End application
        Me.Close()

    End Sub

    Private Sub AddRecordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddRecordToolStripMenuItem.Click
        frmAddNewContact.ShowDialog()
    End Sub

    Private Sub SearchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchToolStripMenuItem.Click
        frmSearch.ShowDialog()
    End Sub
End Class
