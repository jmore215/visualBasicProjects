﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 7/10/20

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.


Imports ContactBO
Imports ContactDO

Public Class frmAddNewContact

    Private mContact As New ContactDO.ContactDO()

    Private Sub btnSaveRecord_Click(sender As Object, e As EventArgs) Handles btnSaveRecord.Click
        Try
            'If the form is valid
            If FormValid() Then

                Dim strPhoneNumber As String = ""
                Dim intIDNumber As Integer = mContact.items.Rows.Count + 1

                strPhoneNumber = "(" + txtTelephone.Text.Substring(0, 3) + ") " + txtTelephone.Text.Substring(3, 3) +
                "-" + txtTelephone.Text.Substring(6)

                'Add all values to the Contact table
                If mContact.Insert(intIDNumber, txtFirstName.Text, txtMiddleName.Text, txtLastName.Text, cboType.SelectedItem,
                                 strPhoneNumber, txtExtension.Text, txtEmail.Text) Then

                    'Then, clear the values from the TextBoxes
                    txtFirstName.Text = String.Empty
                    txtMiddleName.Text = String.Empty
                    txtLastName.Text = String.Empty
                    cboType.Text = String.Empty
                    txtTelephone.Text = String.Empty
                    txtExtension.Text = String.Empty
                    txtEmail.Text = String.Empty

                Else
                    Throw New Exception()
                End If
            End If

        Catch ex As NoNullAllowedException
            MessageBox.Show("These input fields cannot be empty: First Name, Last Name, Type, Telephone, Email", "Error")
        Catch ex As FormatException
            MessageBox.Show("Telephone input can't have any text besides 10 digits (ex. 1234567890) Please Try Again", "Error")
        Catch ex As InvalidCastException
            MessageBox.Show("Telephone input requires 10 digits (ex. 1234567890) Please Try Again", "Error")
        Catch ex As Exception
            MessageBox.Show("An error has occurred, please try again.", "Error")
        End Try

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'Clear all values from TextBoxes
        txtFirstName.Text = String.Empty
        txtMiddleName.Text = String.Empty
        txtLastName.Text = String.Empty
        cboType.Text = String.Empty
        txtTelephone.Text = String.Empty
        txtExtension.Text = String.Empty
        txtEmail.Text = String.Empty

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        'Close the form without saving data
        Me.Close()

    End Sub

    'Evaluate to make sure the required input fields are valid 
    Public Function FormValid() As Boolean

        Dim blnFlag As Boolean = False
        Dim intTestPhone As Integer = 0

        'Throw a no null exception if required fields are null
        If txtFirstName.Text <> String.Empty Then
            If txtLastName.Text <> String.Empty Then
                If cboType.SelectedIndex <> -1 Then
                    If txtTelephone.Text <> String.Empty Then

                        'Also test if telephone input is numeric
                        If IsNumeric(txtTelephone.Text) Then
                            'Then also test if the phone number has 10 digits
                            If CInt(txtTelephone.Text) > 1000000000 And CInt(txtTelephone.Text) < 9999999999 Then

                                If txtEmail.Text <> String.Empty Then

                                    'If the nested if reaches this point, set flag to true
                                    blnFlag = True

                                Else
                                    Throw New NoNullAllowedException()
                                End If
                            Else
                                Throw New InvalidCastException()
                            End If
                        Else
                            Throw New FormatException()
                        End If

                    Else
                        Throw New NoNullAllowedException()
                    End If
                Else
                    Throw New NoNullAllowedException()
                End If
            Else
                Throw New NoNullAllowedException()
            End If
        Else
            Throw New NoNullAllowedException()
        End If

        'return boolean flag
        Return blnFlag

    End Function
End Class