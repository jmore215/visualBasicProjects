﻿'Affirmation of Authorship:

'Name: Jennifer Moreno

'Date: 7/10/20

'I affirm that this program was created by me. It is solely my work and ‘does not include any work done by anyone else.


Public Class ContactDO
    Private adapter As New ContactInfoDataSetTableAdapters.TableTableAdapter
    Private current As Integer

    Public Overloads Function Insert(ByVal contactId As Integer,
     ByVal firstName As String, ByVal middleName As String, ByVal lastName As String,
     ByVal type As String, ByVal telephone As String, ByVal extension As String,
     ByVal emailAddress As String) As Boolean
        ' Insert a new row into the Appointments table. Return 
        ' True if successful. If an exception is thrown, 
        ' LastError will hold an error message.
        Try
            'LastError = String.Empty
            adapter.Insert(contactId, firstName, middleName, lastName, type, telephone, extension, emailAddress)
            Return True
        Catch ex As Exception
            'LastError = ex.Message
            Return False
        End Try
    End Function

    Public ReadOnly Property items As DataTable
        Get
            Return adapter.GetData
        End Get
    End Property

    Public Sub New()
        current = 0
    End Sub

    Public Function GetNext() As Integer
        If current < items.Rows.Count - 1 Then
            current = current + 1
        End If
        Return current
    End Function

    Public Function GetPrev() As Integer
        If current > 0 Then
            current = current - 1
        End If
        Return current
    End Function
End Class
