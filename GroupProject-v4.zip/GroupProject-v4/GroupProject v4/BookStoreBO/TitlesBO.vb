﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...

Imports BookStoreDO

Public Class TitlesBO
    Private adapterTitles As New BookStoreDataSetTableAdapters.titlesTableAdapter()
    Private adapterTitleAuthor As New BookStoreDataSetTableAdapters.titleauthorTableAdapter()
    Private adapterAuthor As New BookStoreDataSetTableAdapters.authorsTableAdapter()
    'Private currentTitle As Integer

    Public Structure BookTitles
        Public TitleID As String
        Public Title As String
        Public Type As String
        Public PubID As String
        Public Price As Decimal
        Public Advance As Double
        Public Royalty As Integer
        Public YTDSales As Integer
        Public Notes As String
        Public PubDate As String
    End Structure

    Public aBookTitle As New BookTitles

    Public Property TitleID As String
    Public Property Title As String
    Public Property Type As String
    Public Property PubID As String
    Public Property Price As Decimal
    Public Property Advance As Double
    Public Property Royalty As Integer
    Public Property YTDSales As Integer
    Public Property Notes As String
    Public Property PubDate As String


    Dim AuthorTitleID(adapterTitleAuthor.GetData.Rows.Count) As String
    Public Property AuthorLName As String
    Public Property AuthorFName As String


    Public Sub New(ByVal pTitleID As String, ByVal pTitle As String, ByVal pPrice As Decimal)
        aBookTitle.TitleID = pTitleID
        aBookTitle.Title = pTitle
        aBookTitle.Price = pPrice

        'TitleID = pTitleID
        'Title = pTitle
        'Price = pPrice

    End Sub

    Public Sub New()
    End Sub

    'Public Sub New(ByVal pTitle As String, ByVal pType As String, ByVal pPrice As Decimal, ByVal pAFName As String, ByVal pALName As String)

    '    Title = pTitle
    '    Type = pType
    '    Price = pPrice
    '    AuthorFName = pAFName
    '    AuthorLName = pALName

    'End Sub

    'Public Sub New(ByVal pTitle As String, ByVal pType As String)

    '    Title = pTitle
    '    Type = pType
    'End Sub


    Public Overrides Function ToString() As String
        Return aBookTitle.TitleID.Trim + ", " + aBookTitle.Title.Trim + ", " + CStr(aBookTitle.Price).Trim
    End Function

    'Public Overrides Function ToString() As String
    '    Return Title + ", " + CStr(Type) + ", " + Price.ToString(Price)
    'End Function

    'Public Overrides Function ToString() As String
    '    Return Title + ", " + CStr(Type) + ", " + CStr(Price) + ", " + CStr(AuthorLName) + ", " + CStr(AuthorFName)
    'End Function

    Public ReadOnly Property itemsTitles As DataTable
        Get
            Return adapterTitles.GetData
        End Get
    End Property

    Public ReadOnly Property itemsAuthors As DataTable
        Get
            Return adapterAuthor.GetData
        End Get
    End Property

End Class
