﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...


Public Class BooksInfo
    Private adapter As New BookStoreDataSetTableAdapters.authorsTableAdapter()

    Public ReadOnly Property items As DataTable
        Get
            Return adapter.GetData
        End Get
    End Property

End Class
