﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...

Public Class frmOrder
    Private Sub SalesBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles SalesBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.SalesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.BookStoreDataSet)

    End Sub

    Private Sub frmOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BookStoreDataSet.sales' table. You can move, or remove it, as needed.
        Me.SalesTableAdapter.Fill(Me.BookStoreDataSet.sales)

    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Me.SalesTableAdapter.Fill(Me.BookStoreDataSet.sales)
    End Sub
End Class