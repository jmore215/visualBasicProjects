﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Emmanuel Okafor

Public Class TitlesDO
    Private adapter As New BookStoreDataSetTableAdapters.titlesTableAdapter


    Public ReadOnly Property items As DataTable
        Get
            Return adapter.GetData
        End Get
    End Property

    '
    Public Overloads Function Insert(ByVal title_id As String, ByVal title As String, ByVal Type As String, ByVal pub_id As String,
                                     ByVal price As Decimal, ByVal advance As Decimal, ByVal royalty As Integer,
                                     ByVal ytd_sales As Integer, ByVal notes As String, ByVal pubdate As Date) As Boolean
        Try
            adapter.Insert(title_id, title, Type, pub_id, price, advance, royalty, ytd_sales, notes, pubdate)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
End Class