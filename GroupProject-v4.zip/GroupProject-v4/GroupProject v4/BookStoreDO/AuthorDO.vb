﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Emmanuel Okafor

Public Class AuthorDO

    Private adapter As New BookStoreDataSetTableAdapters.authorsTableAdapter
    Public ReadOnly Property items As DataTable
        Get
            Return adapter.GetData
        End Get
    End Property

    Public Overloads Function Insert(ByVal au_ID As String, ByVal au_lname As String, ByVal au_fname As String,
                       ByVal phone As String, ByVal address As String, ByVal city As String,
                                     ByVal state As String, ByVal zip As String, ByVal contract As Boolean) As Boolean

        Try
            adapter.Insert(au_ID, au_lname, au_fname, phone, address, city, state, zip, contract)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class

