﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Emmanuel Okafor

Public Class PublishersDO
    Private adapter As New BookStoreDataSetTableAdapters.publishersTableAdapter

    Public ReadOnly Property Items As DataTable
        Get
            Return adapter.GetData
        End Get
    End Property

    Public Overloads Function Insert(ByVal pub_id As String, ByVal pub_name As String, ByVal city As String, ByVal state As String,
                                     ByVal country As String) As Boolean
        Try
            adapter.Insert(pub_id, pub_name, city, state, country)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
End Class