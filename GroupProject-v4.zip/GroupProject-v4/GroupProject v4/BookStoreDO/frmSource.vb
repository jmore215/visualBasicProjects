﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...

Public Class frmSource
    Private Sub TitleauthorBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TitleauthorBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TitleauthorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.BookStoreDataSet)

    End Sub

    Private Sub Source_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BookStoreDataSet.titles' table. You can move, or remove it, as needed.
        Me.TitlesTableAdapter.Fill(Me.BookStoreDataSet.titles)
        'TODO: This line of code loads data into the 'BookStoreDataSet.authors' table. You can move, or remove it, as needed.
        Me.AuthorsTableAdapter.Fill(Me.BookStoreDataSet.authors)
        'TODO: This line of code loads data into the 'BookStoreDataSet.titleauthor' table. You can move, or remove it, as needed.
        Me.TitleauthorTableAdapter.Fill(Me.BookStoreDataSet.titleauthor)

    End Sub


End Class