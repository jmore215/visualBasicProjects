﻿Partial Class BookStoreDataSet
    Partial Public Class salesDataTable
        Private Sub salesDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.qtyColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class
End Class

Namespace BookStoreDataSetTableAdapters

    Partial Public Class titleauthorTableAdapter


    End Class
End Namespace
