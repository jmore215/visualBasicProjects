﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...

Public Class SalesDO
    Private adapter As New BookStoreDataSetTableAdapters.salesTableAdapter

    Public ReadOnly Property Items As DataTable
        Get
            Return adapter.GetData
        End Get
    End Property

    Public Overloads Function Insert(ByVal strStorID As String, ByVal strOrderNum As String, ByVal dtOrderDate As Date,
                           ByVal intQuantity As Integer, ByVal strPayTerms As String, ByVal strTitleId As String) As Boolean

        Try
            adapter.Insert(strStorID, strOrderNum, dtOrderDate, intQuantity, strPayTerms, strTitleId)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class
