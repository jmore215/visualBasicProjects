﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMaintenanceAuthors
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnAddAuthor = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.txtAuthorLName = New System.Windows.Forms.TextBox()
        Me.txtAuthorFName = New System.Windows.Forms.TextBox()
        Me.txtAuthorAddress = New System.Windows.Forms.TextBox()
        Me.txtAuthorCity = New System.Windows.Forms.TextBox()
        Me.txtAuthorZip = New System.Windows.Forms.TextBox()
        Me.cboAState = New System.Windows.Forms.ComboBox()
        Me.lblAuthorId = New System.Windows.Forms.Label()
        Me.chkContract = New System.Windows.Forms.CheckBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(199, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Add New Author"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(56, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Author ID:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Author Last Name:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Author First Name:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(60, 161)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Phone #:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(276, 57)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Address:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(297, 93)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(27, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "City:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(289, 127)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "State:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(271, 161)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Zip Code:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnAddAuthor
        '
        Me.btnAddAuthor.Location = New System.Drawing.Point(63, 229)
        Me.btnAddAuthor.Name = "btnAddAuthor"
        Me.btnAddAuthor.Size = New System.Drawing.Size(90, 33)
        Me.btnAddAuthor.TabIndex = 10
        Me.btnAddAuthor.Text = "Add Author"
        Me.btnAddAuthor.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(216, 229)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(90, 33)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(373, 229)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(90, 33)
        Me.btnCancel.TabIndex = 12
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'txtAuthorLName
        '
        Me.txtAuthorLName.Location = New System.Drawing.Point(117, 90)
        Me.txtAuthorLName.MaxLength = 40
        Me.txtAuthorLName.Name = "txtAuthorLName"
        Me.txtAuthorLName.Size = New System.Drawing.Size(134, 20)
        Me.txtAuthorLName.TabIndex = 1
        '
        'txtAuthorFName
        '
        Me.txtAuthorFName.Location = New System.Drawing.Point(117, 124)
        Me.txtAuthorFName.MaxLength = 20
        Me.txtAuthorFName.Name = "txtAuthorFName"
        Me.txtAuthorFName.Size = New System.Drawing.Size(134, 20)
        Me.txtAuthorFName.TabIndex = 2
        '
        'txtAuthorAddress
        '
        Me.txtAuthorAddress.Location = New System.Drawing.Point(330, 54)
        Me.txtAuthorAddress.MaxLength = 40
        Me.txtAuthorAddress.Name = "txtAuthorAddress"
        Me.txtAuthorAddress.Size = New System.Drawing.Size(134, 20)
        Me.txtAuthorAddress.TabIndex = 4
        '
        'txtAuthorCity
        '
        Me.txtAuthorCity.Location = New System.Drawing.Point(330, 90)
        Me.txtAuthorCity.MaxLength = 20
        Me.txtAuthorCity.Name = "txtAuthorCity"
        Me.txtAuthorCity.Size = New System.Drawing.Size(134, 20)
        Me.txtAuthorCity.TabIndex = 5
        '
        'txtAuthorZip
        '
        Me.txtAuthorZip.AutoCompleteCustomSource.AddRange(New String() {"AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DC", "DE", "FL", "GA", "HI", "IA", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY"})
        Me.txtAuthorZip.Location = New System.Drawing.Point(330, 158)
        Me.txtAuthorZip.MaxLength = 5
        Me.txtAuthorZip.Name = "txtAuthorZip"
        Me.txtAuthorZip.Size = New System.Drawing.Size(134, 20)
        Me.txtAuthorZip.TabIndex = 7
        '
        'cboAState
        '
        Me.cboAState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAState.FormattingEnabled = True
        Me.cboAState.Location = New System.Drawing.Point(330, 123)
        Me.cboAState.Name = "cboAState"
        Me.cboAState.Size = New System.Drawing.Size(133, 21)
        Me.cboAState.Sorted = True
        Me.cboAState.TabIndex = 6
        '
        'lblAuthorId
        '
        Me.lblAuthorId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAuthorId.Location = New System.Drawing.Point(117, 54)
        Me.lblAuthorId.Name = "lblAuthorId"
        Me.lblAuthorId.Size = New System.Drawing.Size(134, 20)
        Me.lblAuthorId.TabIndex = 25
        Me.lblAuthorId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkContract
        '
        Me.chkContract.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkContract.Location = New System.Drawing.Point(264, 184)
        Me.chkContract.Name = "chkContract"
        Me.chkContract.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.chkContract.Size = New System.Drawing.Size(80, 26)
        Me.chkContract.TabIndex = 8
        Me.chkContract.Text = ": Contract"
        Me.chkContract.UseVisualStyleBackColor = True
        '
        'txtPhone
        '
        Me.txtPhone.AutoCompleteCustomSource.AddRange(New String() {"AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DC", "DE", "FL", "GA", "HI", "IA", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY"})
        Me.txtPhone.Location = New System.Drawing.Point(117, 158)
        Me.txtPhone.MaxLength = 10
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(134, 20)
        Me.txtPhone.TabIndex = 3
        '
        'frmMaintenanceAuthors
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(496, 270)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.chkContract)
        Me.Controls.Add(Me.lblAuthorId)
        Me.Controls.Add(Me.cboAState)
        Me.Controls.Add(Me.txtAuthorZip)
        Me.Controls.Add(Me.txtAuthorCity)
        Me.Controls.Add(Me.txtAuthorAddress)
        Me.Controls.Add(Me.txtAuthorFName)
        Me.Controls.Add(Me.txtAuthorLName)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAddAuthor)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmMaintenanceAuthors"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Maintenance - Authors"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btnAddAuthor As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents txtAuthorLName As TextBox
    Friend WithEvents txtAuthorFName As TextBox
    Friend WithEvents txtAuthorAddress As TextBox
    Friend WithEvents txtAuthorCity As TextBox
    Friend WithEvents txtAuthorZip As TextBox
    Friend WithEvents cboAState As ComboBox
    Friend WithEvents lblAuthorId As Label
    Friend WithEvents chkContract As CheckBox
    Friend WithEvents txtPhone As TextBox
End Class
