﻿'Affirmation of Authorship:

'Names: Jennifer Moreno, Andy Naranjo, Emmanuel Okafor, Denver Pomilban

'Date: 07/13/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.
Imports BookStoreDO

Public Class modIDGen
    Dim mTitle As New TitlesDO
    Dim mAuthor As New AuthorDO
    Dim mPublisher As New PublishersDO
    Dim mSales As New SalesDO

    'Random Variables
    Dim intIDGen2Digit As Integer
    Dim intIDGen4Digit As Integer
    Dim intIDGen20Digit As Long

    'Function Variables
    Dim intCounter As Integer = 0
    Dim strNewID As String = ""

    Public Function PubIdGen() As String
        intIDGen4Digit = Int((99 * Rnd()) + 9900)
        intCounter = 0
        strNewID = ""
        Try
            While intCounter < mPublisher.Items.Rows.Count
                If mPublisher.Items.Rows(intCounter)("pub_id") = intIDGen4Digit Then
                    intIDGen4Digit = Int((99 * Rnd()) + 9900)
                    intCounter = 0
                Else
                    strNewID = intIDGen4Digit.ToString
                    intCounter += 1
                End If
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Return strNewID
    End Function

    Public Function AuthorIdGen() As String
        intIDGen2Digit = Int((89 * Rnd()) + 10)
        intIDGen4Digit = Int((8999 * Rnd()) + 1000)

        strNewID = intIDGen4Digit & "-" & intIDGen2Digit & "-" & intIDGen4Digit
        intCounter = 0
        Try
            While intCounter < mAuthor.items.Rows.Count
                If mAuthor.items.Rows(intCounter)("au_id") = strNewID Then
                    intIDGen2Digit = Int((89 * Rnd()) + 10)
                    intIDGen4Digit = Int((8999 * Rnd()) + 1000)
                    strNewID = intIDGen4Digit & "-" & intIDGen2Digit & "-" & intIDGen4Digit
                    intCounter = 0
                Else
                    intCounter += 1
                End If
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Return strNewID
    End Function

    Public Function OrderIdGen() As String
        intIDGen20Digit = CLng((99999999999999999 * Rnd()) + 1)
        intCounter = 0
        strNewID = intIDGen20Digit.ToString
        Try
            While intCounter < mSales.Items.Rows.Count
                If mSales.Items.Rows(intCounter)("ord_num") = strNewID Then
                    intIDGen20Digit = CLng((99999999999999999 * Rnd()) + 1)
                    strNewID = intIDGen20Digit.ToString
                    intCounter = 0
                Else
                    strNewID = intIDGen20Digit.ToString
                    intCounter += 1
                End If
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Order Id Error")

        End Try
        Return strNewID
    End Function



End Class
