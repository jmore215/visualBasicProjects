﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/20/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

Imports BookStoreDO
Public Class modCboPopulation
    Dim mStoreDO As New StoreDO
    Dim mPublisherDO As New PublishersDO

    Public Sub FillPubIDCombo()
        Dim intCounter As Integer = 0

        While intCounter < mPublisherDO.Items.Rows.Count
            If IsDBNull(mPublisherDO.Items.Rows(intCounter)("pub_id")) Then
                intCounter += 1
            Else
                frmMaintenanceTitles.cboPublisherID.Items.Add(mPublisherDO.Items.Rows(intCounter)("pub_id"))
                intCounter += 1
            End If
        End While
    End Sub



    Public Sub FillStoreIDCombo()
        Dim intCounter As Integer = 0

        While intCounter < mStoreDO.items.Rows.Count
            If IsDBNull(mStoreDO.items.Rows(intCounter)("stor_id")) Then
                intCounter += 1

            Else
                frmOrderConfirmation.cboStoreID.Items.Add(mStoreDO.items.Rows(intCounter)("stor_id"))
                intCounter += 1
            End If
        End While
    End Sub


    Public Sub FillState()
        Dim strStates As String = ",AK,AL,AR,AZ,CA,CO,CT,DC,DE,FL,GA,HI,IA,ID,IL,IN,KS,KY,LA,MA,MD,ME,MI,MN,MO,MS,MT,NC,ND,NE,NH,NJ,NM,NV,NY,OH,OK,OR,PA,RI,SC,SD,TN,TX,UT,VA,VT,WA,WI,WV,WY"

        For Each strItem As String In Split(strStates, Chr(44))
            frmMaintenanceAuthors.cboAState.Items.Add(strItem)
            frmMaintenancePublishers.cboPState.Items.Add(strItem)
        Next
    End Sub




End Class
