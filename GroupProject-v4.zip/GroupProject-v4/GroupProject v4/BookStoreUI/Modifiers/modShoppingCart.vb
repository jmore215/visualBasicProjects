﻿'Affirmation of Authorship:

'Names: Jennifer Moreno, Andy Naranjo, Emmanuel Okafor, Denver Pomilban

'Date: 07/13/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.
Module modShoppingCart

    'Global variables for calculation results
    Public decProductSum As Decimal = 0.0
    Public decTax As Decimal = 0.0

    Public Sub Products()

        Dim intIndex As Integer = 0

        Dim intIndexPrice As Integer = 0

        'MAKE SURE DATA TYPE OK WHEN PUTTING INTO SALES TABLE!!!
        decProductSum = 0.0
        Dim decItemPrice As Decimal = 0.0

        For Each strItem As String In frmShoppingCart.lstShoppingCart.Items

            'split the current item into its own array
            Dim arrItems() As String = frmShoppingCart.lstShoppingCart.Items.Item(intIndex).ToString.Split(", ")

            'go through each item in the array
            While intIndexPrice < arrItems.Count

                'if current index of the array is the decimal price
                If Decimal.TryParse(arrItems(intIndexPrice).ToString.Trim, decItemPrice) Then
                    'trim and cast the current index item into a decimal price
                    decItemPrice = CDec(arrItems(intIndexPrice).ToString.Trim)
                End If
                intIndexPrice += 1
            End While
            'when finished, reset index for the next array
            intIndexPrice = 0

            'Add this price into the overall total
            decProductSum += decItemPrice

            frmShoppingCart.lblSubtotal.Text = decProductSum.ToString("c")

            'increase the index to place a different item into the array for processing
            intIndex += 1
        Next
    End Sub

    Public Sub Tax()

        'reset the value before calculating  
        decTax = 0.0
        'set the tax rate to 6%
        Dim decRate As Decimal = 0.06

        'calculate tax by multiplying Product Sum by tax rate
        decTax = decProductSum * decRate

        'Populate lblTax in the shopping cart in proper format
        frmShoppingCart.lblTax.Text = decTax.ToString("c")

    End Sub

    Public Sub Total()

        'set total to 0.0 before calculating
        Dim decTotal As Decimal = 0.0

        'calculate total
        decTotal = decProductSum + decTax

        'populate lblTotal in the shopping cart in proper format
        frmShoppingCart.lblTotal.Text = decTotal.ToString("c")

    End Sub
End Module
