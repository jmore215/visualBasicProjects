﻿'Affirmation of Authorship:

'Names: Jennifer Moreno, Andy Naranjo, Emmanuel Okafor, Denver Pomilban

'Date: 07/13/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

Imports BookStoreDO

Public Class modOrderConfirmation

    Dim mSaleDo As New SalesDO

    Public Function ItemListCalc(ByVal intItemLst As Integer) As Integer
        Dim intCounter, intListEnd As Integer
        Dim arrItemList(intItemLst) As String
        Dim test As String

        intCounter = 0
        intListEnd = intItemLst

        For Each strItem As String In Split(frmOrderConfirmation.lstItemsOrdered.SelectedItem(intCounter).ToString, Chr(44))

        Next


        While intCounter < intListEnd







        End While

        Return 0
    End Function

End Class
