﻿'Affirmation of Authorship:

'Names: Jennifer Moreno, Andy Naranjo, Emmanuel Okafor, Denver Pomilban

'Date: 07/13/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

Imports BookStoreDO

Public Class modReport
    Dim salesReport As New SalesDO
    Dim titleReport As New TitlesDO

    Public Structure soldItems
        Public strOrderId As String
        Public strTitleId As String
        Public strTitleName As String
        Public intQty As Integer
        Public dtOrderDate As Date
        Public dblTotalValue As Double
    End Structure



    Public Sub dateReport(ByVal dtStart As Date, ByVal dtFinish As Date)
        Dim saleItem As soldItems
        Dim itemFound As Boolean = False
        Dim intCounterSale As Integer = 0

        Try

            While intCounterSale < salesReport.Items.Rows.Count

                If salesReport.Items.Rows(intCounterSale)("ord_date") >= dtStart.Date And salesReport.Items.Rows(intCounterSale)("ord_date") <= dtFinish.Date Then

                    saleItem.strOrderId = "Order ID: " & salesReport.Items.Rows(intCounterSale)("ord_num") & " | "
                    saleItem.strTitleId = salesReport.Items.Rows(intCounterSale)("title_id")
                    saleItem.intQty = salesReport.Items.Rows(intCounterSale)("qty")
                    saleItem.dtOrderDate = salesReport.Items.Rows(intCounterSale)("ord_date")

                    Dim intCounterTitle As Integer = 0
                    While intCounterTitle < titleReport.items.Rows.Count
                        If titleReport.items.Rows(intCounterTitle)("title_id").ToString.Contains(saleItem.strTitleId) Then
                            saleItem.strTitleName = "Title Name: " & titleReport.items.Rows(intCounterTitle)("title") & " | "
                            saleItem.dblTotalValue = titleReport.items.Rows(intCounterTitle)("price") * saleItem.intQty
                        End If

                        intCounterTitle += 1
                    End While

                    frmReport.lstReportItems.Items.Add(saleItem.strOrderId &
                                                        "Title id: " & saleItem.strTitleId & " | " &
                                                        saleItem.strTitleName &
                                                        "Quantity: " & saleItem.intQty & " | " &
                                                        "Order Date: " & FormatDateTime(saleItem.dtOrderDate) & " | " &
                                                        "Total Value: " & FormatCurrency(saleItem.dblTotalValue))
                    itemFound = True
                End If

                intCounterSale += 1

            End While

            If intCounterSale = salesReport.Items.Rows.Count And itemFound = False Then
                MessageBox.Show("There were not items sold in the selected dates", "Message")

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Report Error!")
        End Try
    End Sub






End Class
