﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Emmanuel Okafor

Imports BookStoreDO
Public Class frmMaintenanceTitles
    Dim idPublisher As New modCboPopulation
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        'close page
        Me.Close()
    End Sub

    Private Sub frmMaintenanceTitles_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Create variables to store database values 
        Dim intTIDGen4Digit As Integer = Int((8999 * Rnd()) + 1000)
        idPublisher.FillPubIDCombo()
        lblTitleId.Text = intTIDGen4Digit
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'clear all fields when clear button is click
        txtTitle.Clear()
        txtType.Clear()
        txtPrice.Clear()
        txtAdvance.Clear()
        txtRoyalty.Clear()
        txtYTDSales.Clear()
        txtNotes.Clear()
        cboPublisherID.ResetText()

    End Sub

    Private Sub btnAddTitle_Click(sender As Object, e As EventArgs) Handles btnAddTitle.Click
        Dim mTitlesDO As New TitlesDO

        'validate all information entered by user in all fields
        Try

            If IsNumeric(txtTitle.Text) = False And txtTitle.Text.Length > 1 Then

            Else
                MessageBox.Show("Please make sure that the tile is correct", "Warning")
            End If

            If IsNumeric(txtType.Text) = False And txtType.Text.Length > 1 Then

            Else
                MessageBox.Show("Please make sure that the Type is correct", "Warning")
            End If

            If txtPrice.Text.Length > 0 And IsNumeric(CDbl(txtPrice.Text)) And CDbl(txtPrice.Text) > 0 Then

            Else
                MessageBox.Show("Please enter a valid currency amount.", "Warning")
            End If

            If txtAdvance.Text.Length > 0 And IsNumeric(CDbl(txtAdvance.Text)) And CDbl(txtAdvance.Text) > 0 Then

            Else
                MessageBox.Show("Please enter a valid currency amount.", "Warning")
            End If

            If IsNumeric(txtRoyalty.Text) Then

            Else
                MessageBox.Show("Please enter a valid currency amount.", "Warning")
            End If

            If IsNumeric(txtYTDSales.Text) Then
            Else
                MessageBox.Show("Please Enter a Number for The YTD ", "Warning")
            End If

            If cboPublisherID.SelectedIndex >= 0 Then

            Else
                        MessageBox.Show("Please select an Publisher ID from list", "Warning")
                    End If

            'insert user information into the Publisher database
            mTitlesDO.Insert(lblTitleId.Text, txtTitle.Text, txtType.Text, cboPublisherID.Text, CDbl(txtPrice.Text), CDbl(txtAdvance.Text),
                             CInt(txtRoyalty.Text), CInt(txtYTDSales.Text), txtNotes.Text, dtpPubDate.Value.Date)

            'reset combo box and close form
            cboPublisherID.ResetText()
            Me.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try

    End Sub
End Class