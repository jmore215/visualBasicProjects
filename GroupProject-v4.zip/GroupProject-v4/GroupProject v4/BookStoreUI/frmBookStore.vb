﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...

Imports BookStoreDO
Imports BookStoreBO

Public Class frmBookStore


    Private mBook As New BooksInfo
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

    Private Sub ShoppingCartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuShoppingCart.Click
        frmShoppingCart.ShowDialog()
    End Sub

    Private Sub TitlesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuMaintTitles.Click
        frmMaintenanceTitles.ShowDialog()
    End Sub

    Private Sub AuthorsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuMaintAuthor.Click
        frmMaintenanceAuthors.ShowDialog()
    End Sub

    Private Sub PublishersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuMaintPublisher.Click
        frmMaintenancePublishers.ShowDialog()
    End Sub

    Private Sub ReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuReport.Click
        frmReport.ShowDialog()
    End Sub

    Private Sub SourceToolStripMenuItem_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub TitleSourceToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim titleSource As New frmSource
        titleSource.Show()
    End Sub

    Private Sub OrerSourceToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim orderSource As New frmOrder
        orderSource.Show()
    End Sub

    Private Sub MaintananceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaintananceToolStripMenuItem.Click
        Dim sMaintanace As New frmMaintenance
        sMaintanace.Show()
    End Sub

    Private Sub OrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderToolStripMenuItem.Click
        Dim sOrder As New frmOrder
        sOrder.Show()
    End Sub

    Private Sub frmBookStore_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
