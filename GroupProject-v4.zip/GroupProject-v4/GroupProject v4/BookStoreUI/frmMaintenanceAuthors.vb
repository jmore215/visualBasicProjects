﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Emmanuel Okafor

Imports BookStoreDO
Public Class frmMaintenanceAuthors

    'Define classes
    Dim mAuthorDO As New AuthorDO
    Dim mAthIDGen As New modIDGen
    Dim mAState As New modCboPopulation



    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        'close page on when Cancel button is click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'clear fields on button click
        txtAuthorLName.Clear()
        txtAuthorFName.Clear()
        txtPhone.Clear()
        txtAuthorAddress.Clear()
        txtAuthorCity.Clear()
        cboAState.ResetText()
        txtAuthorZip.Clear()
        chkContract.CheckState = False
    End Sub

    Private Sub frmMaintenanceAuthors_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'reset all field when page loads
        txtAuthorLName.Clear()
        txtAuthorFName.Clear()
        txtPhone.Clear()
        txtAuthorAddress.Clear()
        txtAuthorCity.Clear()
        cboAState.ResetText()
        txtAuthorZip.Clear()
        chkContract.CheckState = False

        '
        mAState.FillState()
        lblAuthorId.Text = mAthIDGen.AuthorIdGen()

    End Sub

    Private Sub btnAddAuthor_Click(sender As Object, e As EventArgs) Handles btnAddAuthor.Click

        'validate all information entered by user in all fields
        Try
            If IsNumeric(txtAuthorLName.Text) = False And txtAuthorLName.Text.Length > 1 Then

            Else
                MessageBox.Show("Please make sure that last name is correct", "Warning")
            End If

            If IsNumeric(txtAuthorFName.Text) = False And txtAuthorFName.Text.Length > 1 Then

            Else
                MessageBox.Show("Please make sure that fisrt name is correct", "Warning")
            End If


            If IsNumeric(txtPhone.Text) And txtPhone.Text.Length = 10 Then

            Else
                MessageBox.Show("Please make sure your phone number is correct", "Warning")
            End If

            If IsNumeric(txtAuthorAddress.Text) = False And txtAuthorAddress.Text.Length > 1 Then

            Else
                MessageBox.Show("Please verify address", "Warning")
            End If

            If IsNumeric(txtAuthorCity.Text) = False And txtAuthorCity.Text.Length > 1 Then

            Else
                MessageBox.Show("Please enter a valid city", "Warning")
            End If

            If cboAState.SelectedIndex >= 1 Then

            Else
                MessageBox.Show("Please select state from list", "Warning")
            End If

            If IsNumeric(txtAuthorZip.Text) And txtAuthorZip.Text.Length = 5 Then

            Else
                MessageBox.Show("Please enter a valid zipcode", "Warning")
            End If


            'insert users input into the database
            mAuthorDO.Insert(lblAuthorId.Text.ToString, txtAuthorLName.Text.ToString, txtAuthorFName.Text.ToString,
                             txtPhone.Text.ToString.ToString, txtAuthorAddress.Text.ToString, txtAuthorCity.Text.ToString,
                             cboAState.SelectedItem, txtAuthorZip.Text.ToString, chkContract.Checked)

            'reset combo box and close form
            cboAState.ResetText()
            Me.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try

    End Sub
End Class