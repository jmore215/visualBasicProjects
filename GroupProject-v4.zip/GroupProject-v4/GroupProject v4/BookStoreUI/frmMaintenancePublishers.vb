﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Emmanuel Okafor


Imports BookStoreDO

Public Class frmMaintenancePublishers

    'defines classes 
    Dim mPubLishersDO As New PublishersDO
    Dim mIdGen As New modIDGen
    Dim mPubState As New modCboPopulation


    Private Sub frmMaintenancePublishers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'reset all field when page loads
        txtPubName.Focus()
        txtPubCity.Clear()
        cboPState.ResetText()
        txtPubCountry.Clear()

        'assign a number to new Publisher entered
        lblPublisherId.Text = mIdGen.PubIdGen()
        mPubState.FillState()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        'close page wheen cancle button is clicked
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'clear all fields when clear button is click
        txtPubCity.Clear()
        cboPState.ResetText()
        txtPubCountry.Clear()
    End Sub

    Private Sub btnAddPublisher_Click(sender As Object, e As EventArgs) Handles btnAddPublisher.Click

        'validate all information entered by user in all fields
        Try
            If IsNumeric(txtPubName.Text) = False And txtPubName.Text.Length > 1 Then

            Else
                MessageBox.Show("Please verify the Publisher's name is correct", "Warning")
            End If


            If IsNumeric(txtPubCity.Text) = False And txtPubCity.Text.Length > 1 Then

            Else
                MessageBox.Show("Please verify the Publisher's city is correct", "Warning")
            End If


            If cboPState.SelectedIndex >= 1 Then

            Else
                MessageBox.Show("Please select a state from the list", "Warning")
            End If

            If IsNumeric(txtPubCountry.Text) = False And txtPubCountry.Text.Length > 1 Then

            Else
                MessageBox.Show("Please verify the Publisher's Country is correct", "Warning")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try

        'insert user information into the Publisher database
        mPubLishersDO.Insert(lblPublisherId.Text.ToString, txtPubName.Text, txtPubCity.Text, cboPState.SelectedItem.ToString.Trim, txtPubCountry.Text)

        'close form after insert
        Me.Close()

        'reset lblPublisherId
        lblPublisherId.Text = ""


    End Sub
End Class