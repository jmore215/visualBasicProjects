﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...


Public Class frmSearch
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

        lstSearchResults.Items.Clear()
    End Sub

    Private Sub btnAddToCart_Click(sender As Object, e As EventArgs) Handles btnAddToCart.Click

        'Only add to shopping cart if an item is selected
        If lstSearchResults.SelectedIndex <> -1 Then

            frmShoppingCart.lstShoppingCart.Items.Add(lstSearchResults.SelectedItem.ToString)

            'Update all totals by calling module method
            Products()
            Tax()
            Total()

        Else
            MessageBox.Show("No item selected to place into cart.", "Error")
        End If

        Me.Close()
    End Sub

    Private Sub frmSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class