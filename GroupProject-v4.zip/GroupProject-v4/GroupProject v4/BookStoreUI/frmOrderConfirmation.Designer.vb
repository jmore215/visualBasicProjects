﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrderConfirmation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblOrderNum = New System.Windows.Forms.Label()
        Me.lblONum = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.lblTotalTax = New System.Windows.Forms.Label()
        Me.lblTotalProductCost = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstItemsOrdered = New System.Windows.Forms.ListBox()
        Me.btnYes = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnNo = New System.Windows.Forms.Button()
        Me.dtpOrderDate = New System.Windows.Forms.DateTimePicker()
        Me.lblOrderDate = New System.Windows.Forms.Label()
        Me.cboStoreID = New System.Windows.Forms.ComboBox()
        Me.lblStoreID = New System.Windows.Forms.Label()
        Me.lblPayment = New System.Windows.Forms.Label()
        Me.cboPayment = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'lblOrderNum
        '
        Me.lblOrderNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOrderNum.Location = New System.Drawing.Point(129, 91)
        Me.lblOrderNum.Name = "lblOrderNum"
        Me.lblOrderNum.Size = New System.Drawing.Size(276, 23)
        Me.lblOrderNum.TabIndex = 22
        Me.lblOrderNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblONum
        '
        Me.lblONum.AutoSize = True
        Me.lblONum.Location = New System.Drawing.Point(47, 97)
        Me.lblONum.Name = "lblONum"
        Me.lblONum.Size = New System.Drawing.Size(76, 13)
        Me.lblONum.TabIndex = 21
        Me.lblONum.Text = "Order Number:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(45, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Items Ordered:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTotalCost
        '
        Me.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCost.Location = New System.Drawing.Point(129, 385)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(276, 23)
        Me.lblTotalCost.TabIndex = 19
        Me.lblTotalCost.Text = "lblTotalCost"
        Me.lblTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotalTax
        '
        Me.lblTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalTax.Location = New System.Drawing.Point(129, 348)
        Me.lblTotalTax.Name = "lblTotalTax"
        Me.lblTotalTax.Size = New System.Drawing.Size(276, 23)
        Me.lblTotalTax.TabIndex = 18
        Me.lblTotalTax.Text = "lblTotalTax"
        Me.lblTotalTax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotalProductCost
        '
        Me.lblTotalProductCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalProductCost.Location = New System.Drawing.Point(129, 311)
        Me.lblTotalProductCost.Name = "lblTotalProductCost"
        Me.lblTotalProductCost.Size = New System.Drawing.Size(276, 23)
        Me.lblTotalProductCost.TabIndex = 17
        Me.lblTotalProductCost.Text = "lblTotalProductCost"
        Me.lblTotalProductCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(61, 390)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Total Cost:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(91, 353)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Tax:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(20, 316)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 13)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Total Product Cost:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lstItemsOrdered
        '
        Me.lstItemsOrdered.FormattingEnabled = True
        Me.lstItemsOrdered.HorizontalScrollbar = True
        Me.lstItemsOrdered.Location = New System.Drawing.Point(129, 162)
        Me.lstItemsOrdered.Name = "lstItemsOrdered"
        Me.lstItemsOrdered.Size = New System.Drawing.Size(276, 82)
        Me.lstItemsOrdered.TabIndex = 13
        '
        'btnYes
        '
        Me.btnYes.Location = New System.Drawing.Point(126, 432)
        Me.btnYes.Name = "btnYes"
        Me.btnYes.Size = New System.Drawing.Size(73, 35)
        Me.btnYes.TabIndex = 23
        Me.btnYes.Text = "Yes"
        Me.btnYes.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(162, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 14)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Order Confirmation"
        '
        'btnNo
        '
        Me.btnNo.Location = New System.Drawing.Point(237, 432)
        Me.btnNo.Name = "btnNo"
        Me.btnNo.Size = New System.Drawing.Size(73, 35)
        Me.btnNo.TabIndex = 25
        Me.btnNo.Text = "No"
        Me.btnNo.UseVisualStyleBackColor = True
        '
        'dtpOrderDate
        '
        Me.dtpOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpOrderDate.Location = New System.Drawing.Point(129, 128)
        Me.dtpOrderDate.Name = "dtpOrderDate"
        Me.dtpOrderDate.Size = New System.Drawing.Size(276, 20)
        Me.dtpOrderDate.TabIndex = 26
        '
        'lblOrderDate
        '
        Me.lblOrderDate.AutoSize = True
        Me.lblOrderDate.Location = New System.Drawing.Point(59, 132)
        Me.lblOrderDate.Name = "lblOrderDate"
        Me.lblOrderDate.Size = New System.Drawing.Size(62, 13)
        Me.lblOrderDate.TabIndex = 27
        Me.lblOrderDate.Text = "Order Date:"
        Me.lblOrderDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboStoreID
        '
        Me.cboStoreID.FormattingEnabled = True
        Me.cboStoreID.Location = New System.Drawing.Point(129, 56)
        Me.cboStoreID.Name = "cboStoreID"
        Me.cboStoreID.Size = New System.Drawing.Size(276, 21)
        Me.cboStoreID.TabIndex = 28
        '
        'lblStoreID
        '
        Me.lblStoreID.AutoSize = True
        Me.lblStoreID.Location = New System.Drawing.Point(72, 59)
        Me.lblStoreID.Name = "lblStoreID"
        Me.lblStoreID.Size = New System.Drawing.Size(49, 13)
        Me.lblStoreID.TabIndex = 29
        Me.lblStoreID.Text = "Store ID:"
        Me.lblStoreID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPayment
        '
        Me.lblPayment.AutoSize = True
        Me.lblPayment.Location = New System.Drawing.Point(58, 269)
        Me.lblPayment.Name = "lblPayment"
        Me.lblPayment.Size = New System.Drawing.Size(60, 13)
        Me.lblPayment.TabIndex = 30
        Me.lblPayment.Text = "Pay Terms:"
        Me.lblPayment.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboPayment
        '
        Me.cboPayment.AutoCompleteCustomSource.AddRange(New String() {"Net 30", "Net 60", "ON invoice"})
        Me.cboPayment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboPayment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboPayment.FormattingEnabled = True
        Me.cboPayment.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cboPayment.Items.AddRange(New Object() {"Net 30", "Net 60", "ON invoice"})
        Me.cboPayment.Location = New System.Drawing.Point(129, 266)
        Me.cboPayment.Name = "cboPayment"
        Me.cboPayment.Size = New System.Drawing.Size(276, 21)
        Me.cboPayment.TabIndex = 31
        '
        'frmOrderConfirmation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(426, 490)
        Me.Controls.Add(Me.cboPayment)
        Me.Controls.Add(Me.lblPayment)
        Me.Controls.Add(Me.lblStoreID)
        Me.Controls.Add(Me.cboStoreID)
        Me.Controls.Add(Me.lblOrderDate)
        Me.Controls.Add(Me.dtpOrderDate)
        Me.Controls.Add(Me.btnNo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnYes)
        Me.Controls.Add(Me.lblOrderNum)
        Me.Controls.Add(Me.lblONum)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblTotalTax)
        Me.Controls.Add(Me.lblTotalProductCost)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lstItemsOrdered)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmOrderConfirmation"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order Confirmation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblOrderNum As Label
    Friend WithEvents lblONum As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents lblTotalTax As Label
    Friend WithEvents lblTotalProductCost As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lstItemsOrdered As ListBox
    Friend WithEvents btnYes As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnNo As Button
    Friend WithEvents dtpOrderDate As DateTimePicker
    Friend WithEvents lblOrderDate As Label
    Friend WithEvents cboStoreID As ComboBox
    Friend WithEvents lblStoreID As Label
    Friend WithEvents lblPayment As Label
    Friend WithEvents cboPayment As ComboBox
End Class
