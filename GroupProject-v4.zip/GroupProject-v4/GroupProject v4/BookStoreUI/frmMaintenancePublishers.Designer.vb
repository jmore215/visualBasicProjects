﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMaintenancePublishers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddPublisher = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPubName = New System.Windows.Forms.TextBox()
        Me.txtPubCity = New System.Windows.Forms.TextBox()
        Me.txtPubCountry = New System.Windows.Forms.TextBox()
        Me.cboPState = New System.Windows.Forms.ComboBox()
        Me.lblPublisherId = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnAddPublisher
        '
        Me.btnAddPublisher.Location = New System.Drawing.Point(12, 223)
        Me.btnAddPublisher.Name = "btnAddPublisher"
        Me.btnAddPublisher.Size = New System.Drawing.Size(93, 34)
        Me.btnAddPublisher.TabIndex = 5
        Me.btnAddPublisher.Text = "Add Publisher"
        Me.btnAddPublisher.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(152, 223)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(93, 34)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(291, 223)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(93, 34)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(149, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 14)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Add New Publisher"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(60, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Publisher ID:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Publisher Name:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(100, 116)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "City:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(92, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "State:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(81, 173)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Country:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPubName
        '
        Me.txtPubName.Location = New System.Drawing.Point(133, 83)
        Me.txtPubName.MaxLength = 40
        Me.txtPubName.Name = "txtPubName"
        Me.txtPubName.Size = New System.Drawing.Size(155, 20)
        Me.txtPubName.TabIndex = 1
        '
        'txtPubCity
        '
        Me.txtPubCity.Location = New System.Drawing.Point(133, 113)
        Me.txtPubCity.MaxLength = 20
        Me.txtPubCity.Name = "txtPubCity"
        Me.txtPubCity.Size = New System.Drawing.Size(155, 20)
        Me.txtPubCity.TabIndex = 2
        '
        'txtPubCountry
        '
        Me.txtPubCountry.Location = New System.Drawing.Point(133, 170)
        Me.txtPubCountry.MaxLength = 30
        Me.txtPubCountry.Name = "txtPubCountry"
        Me.txtPubCountry.Size = New System.Drawing.Size(155, 20)
        Me.txtPubCountry.TabIndex = 4
        '
        'cboPState
        '
        Me.cboPState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPState.FormattingEnabled = True
        Me.cboPState.Location = New System.Drawing.Point(133, 141)
        Me.cboPState.Name = "cboPState"
        Me.cboPState.Size = New System.Drawing.Size(155, 21)
        Me.cboPState.TabIndex = 3
        '
        'lblPublisherId
        '
        Me.lblPublisherId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPublisherId.Location = New System.Drawing.Point(133, 53)
        Me.lblPublisherId.Name = "lblPublisherId"
        Me.lblPublisherId.Size = New System.Drawing.Size(155, 20)
        Me.lblPublisherId.TabIndex = 24
        Me.lblPublisherId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMaintenancePublishers
        '
        Me.AcceptButton = Me.btnAddPublisher
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(400, 281)
        Me.Controls.Add(Me.lblPublisherId)
        Me.Controls.Add(Me.cboPState)
        Me.Controls.Add(Me.txtPubCountry)
        Me.Controls.Add(Me.txtPubCity)
        Me.Controls.Add(Me.txtPubName)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAddPublisher)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmMaintenancePublishers"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Maintenance - Publishers"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnAddPublisher As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtPubName As TextBox
    Friend WithEvents txtPubCity As TextBox
    Friend WithEvents txtPubCountry As TextBox
    Friend WithEvents cboPState As ComboBox
    Friend WithEvents lblPublisherId As Label
End Class
