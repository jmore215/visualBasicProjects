﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by Jennifer Moreno

Imports BookStoreBO
Imports BookStoreDO

Public Class frmShoppingCart

    Private mBookTitles As New TitlesBO()
    Dim arrTitles(mBookTitles.itemsTitles.Rows.Count - 1) As TitlesBO

    Private Sub frmShoppingCart_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Empty labels when form first loads
        lblSubtotal.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotal.Text = String.Empty
        lstShoppingCart.Items.Clear()

        Dim intIndex As Integer = 0

        'Create variables to store database values 
        Dim strTitleID As String
        Dim strTitleName As String
        Dim decTitlePrice As Decimal

        'While loop that goes through each row in the Titles table
        While intIndex < mBookTitles.itemsTitles.Rows.Count
            'Check if each value in the Title column is null
            If IsDBNull(mBookTitles.itemsTitles().Rows(intIndex)("title_id")) Then
                strTitleID = ""
            Else
                strTitleID = mBookTitles.itemsTitles().Rows(intIndex)("title_id")

            End If

            'Check if each value in the Title column is null
            If IsDBNull(mBookTitles.itemsTitles().Rows(intIndex)("title")) Then
                strTitleName = ""
            Else
                strTitleName = mBookTitles.itemsTitles().Rows(intIndex)("title")

            End If

            'Check if each value in the Price column is null
            If IsDBNull(mBookTitles.itemsTitles().Rows(intIndex)("price")) Then
                decTitlePrice = 0.00
            Else
                decTitlePrice = mBookTitles.itemsTitles().Rows(intIndex)("price")
            End If

            'Load each set of values into a new Title object
            Dim aTitle As New TitlesBO(strTitleID, strTitleName, decTitlePrice)

            'Add each Title object into the list box
            lstProducts.Items.Add(aTitle.ToString)
            arrTitles(intIndex) = aTitle

            intIndex += 1
        End While
    End Sub

    Private Sub btnPlaceOrder_Click(sender As Object, e As EventArgs) Handles btnPlaceOrder.Click
        If lstShoppingCart.Items.Count > 0 Then
            frmOrderConfirmation.ShowDialog()

        Else
            MessageBox.Show("You can't continue to order confirmation page with no items in your cart.", "Error")
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'Clear search text box
        txtSearch.Text = String.Empty

        'Empty shopping cart
        lstShoppingCart.Items.Clear()

        'Clear all labels
        Products()
        Tax()
        Total()

        'Once there are no items in the cart, reset the label for subtotal
        If lstShoppingCart.Items.Count = 0 Then
            lblSubtotal.Text = "$0.00"
        End If


    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnIntoCart_Click(sender As Object, e As EventArgs) Handles btnIntoCart.Click
        Dim intIndex As Integer

        'Add selected item into lstShoppingCart
        intIndex = lstProducts.SelectedIndex
        If intIndex <> -1 Then
            lstShoppingCart.Items.Add(lstProducts.SelectedItem)

            'Update all totals by calling module method
            Products()
            Tax()
            Total()

        Else
            MessageBox.Show("No item selected to place into cart.", "Error")
        End If
    End Sub

    Private Sub btnOutOfCart_Click(sender As Object, e As EventArgs) Handles btnOutOfCart.Click
        Dim intIndex As Integer

        'Remove selected item from lstShoppingCart
        intIndex = lstShoppingCart.SelectedIndex
        If intIndex <> -1 Then
            lstShoppingCart.Items.RemoveAt(intIndex)

            'Update all totals by calling module method
            Products()
            Tax()
            Total()

            If lstShoppingCart.Items.Count = 0 Then
                lblSubtotal.Text = "$0.00"
            End If
        Else
            MessageBox.Show("No item selected to take out of cart.", "Error")
        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        Dim intIndex As Integer = 0

        'For Each strItem As String In lstProducts.Items
        '    If strItem.Contains(txtSearch.Text) Then

        '        frmSearch.lstSearchResults.Items.Add(lstProducts.Items.Item(intIndex))
        '        'frmSearch.lstSearchResults.Items.Add(arrTitles(intIndex).Price)

        '    End If
        '    intIndex += 1
        'Next
        'frmSearch.ShowDialog()


        'THIS IS THE FIXED VERSION OF LOOP UNDER THIS ONE
        Dim loadTitle As TitlesBO
        Dim loadTitleArrayLowercase As String
        Dim searchLowercase As String

        If txtSearch.Text <> "" Then
            While intIndex < arrTitles.Count
                loadTitle = arrTitles(intIndex)

                'Compare lowercase version of both sets of strings
                loadTitleArrayLowercase = loadTitle.aBookTitle.Title.ToString.ToLower
                ' loadTitleArrayLowercase = loadTitle.Title.ToString.ToLower
                searchLowercase = txtSearch.Text.ToLower

                If loadTitleArrayLowercase.Contains(searchLowercase) Then

                    frmSearch.lstSearchResults.Items.Add(arrTitles(intIndex))

                End If

                intIndex += 1
            End While

            'If there is at least 1 match, display the search results form
            If frmSearch.lstSearchResults.Items.Count > 0 Then
                frmSearch.ShowDialog()
            Else
                'Else, display a message saying no titles matched the search
                MessageBox.Show("No titles match your search, please try a different entry.", "No Matching Results")
            End If

        Else
            MessageBox.Show("Box cannot be empty when performing search.", "Error")
        End If
    End Sub


End Class

