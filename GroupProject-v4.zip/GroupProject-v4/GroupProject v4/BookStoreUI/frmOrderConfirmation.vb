﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by ...

Imports BookStoreDO
Imports BookStoreBO

Public Class frmOrderConfirmation
    Dim mOrderConfirm As New SalesDO
    Dim mOrderIDGen As New modIDGen


    Private Sub frmOrderConfirmation_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim intIndex As Integer = 0
        Dim mComboFill As New modCboPopulation
        'Load the list box with each item in the shopping cart (items in lstShoppingCart are strings)
        While intIndex < frmShoppingCart.lstShoppingCart.Items.Count
            lstItemsOrdered.Items.Add(frmShoppingCart.lstShoppingCart.Items.Item(intIndex))

            intIndex += 1
        End While

        'Load the labels for subtotal, tax, and total with what was in frmShoppingCart

        lblTotalProductCost.Text = frmShoppingCart.lblSubtotal.Text
        lblTotalTax.Text = frmShoppingCart.lblTax.Text
        lblTotalCost.Text = frmShoppingCart.lblTotal.Text
        lblOrderNum.Text = mOrderIDGen.OrderIdGen
        mComboFill.FillStoreIDCombo()


    End Sub

    Private Sub btnNo_Click(sender As Object, e As EventArgs) Handles btnNo.Click
        'If order confirmation is cancelled, then close the form and empty lstItemsOrdered
        Me.Close()
        lstItemsOrdered.Items.Clear()
        cboStoreID.Items.Clear()

    End Sub

    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click

        Dim intIndex As Integer = 0
        Dim strTitleID As String = ""

        If cboStoreID.SelectedItem Then
            If cboPayment.SelectedIndex >= 0 Then
                For Each strItem As String In lstItemsOrdered.Items

                    'split the current item into its own array

                    Dim arrItems() As String = lstItemsOrdered.Items.Item(intIndex).ToString.Split(", ")

                    strTitleID += arrItems(0).ToString.Trim()

                    intIndex += 1
                Next

                mOrderConfirm.Insert(cboStoreID.SelectedItem, lblOrderNum.Text.ToString, dtpOrderDate.Value.Date, lstItemsOrdered.Items.Count, cboPayment.SelectedItem, strTitleID)


                'go back to home screen
                cboStoreID.Items.Clear()
                lstItemsOrdered.Items.Clear()
                Me.Close()
                frmShoppingCart.Close()

            Else
                MessageBox.Show("Please Select a payment Mehtod", "Warning")
            End If
        Else
            MessageBox.Show("Please Select a Store", "Warning")
        End If



    End Sub
End Class