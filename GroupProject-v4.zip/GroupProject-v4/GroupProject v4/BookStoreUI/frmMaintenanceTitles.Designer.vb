﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMaintenanceTitles
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnAddTitle = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.txtType = New System.Windows.Forms.TextBox()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.cboPublisherID = New System.Windows.Forms.ComboBox()
        Me.dtpPubDate = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblTitleId = New System.Windows.Forms.Label()
        Me.txtRoyalty = New System.Windows.Forms.MaskedTextBox()
        Me.txtYTDSales = New System.Windows.Forms.MaskedTextBox()
        Me.PublishersTableAdapter1 = New BookStoreDO.BookStoreDataSetTableAdapters.publishersTableAdapter()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.txtAdvance = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(195, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Add New Title"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(36, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Title:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 121)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Type:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 157)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Price:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 191)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Advance:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(263, 50)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Royalty:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(218, 224)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Notes:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(247, 83)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "YTD Sales:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(253, 117)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Pub Date:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(243, 156)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Publisher ID:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnAddTitle
        '
        Me.btnAddTitle.Location = New System.Drawing.Point(25, 369)
        Me.btnAddTitle.Name = "btnAddTitle"
        Me.btnAddTitle.Size = New System.Drawing.Size(84, 34)
        Me.btnAddTitle.TabIndex = 10
        Me.btnAddTitle.Text = "Add Title"
        Me.btnAddTitle.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(365, 369)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(88, 34)
        Me.btnCancel.TabIndex = 12
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(198, 369)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(84, 34)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(72, 84)
        Me.txtTitle.MaxLength = 80
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(139, 20)
        Me.txtTitle.TabIndex = 1
        '
        'txtType
        '
        Me.txtType.Location = New System.Drawing.Point(72, 118)
        Me.txtType.MaxLength = 12
        Me.txtType.Name = "txtType"
        Me.txtType.Size = New System.Drawing.Size(139, 20)
        Me.txtType.TabIndex = 2
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(25, 250)
        Me.txtNotes.MaxLength = 200
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(428, 91)
        Me.txtNotes.TabIndex = 9
        '
        'cboPublisherID
        '
        Me.cboPublisherID.FormattingEnabled = True
        Me.cboPublisherID.Location = New System.Drawing.Point(314, 153)
        Me.cboPublisherID.Name = "cboPublisherID"
        Me.cboPublisherID.Size = New System.Drawing.Size(139, 21)
        Me.cboPublisherID.TabIndex = 8
        '
        'dtpPubDate
        '
        Me.dtpPubDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpPubDate.Location = New System.Drawing.Point(314, 114)
        Me.dtpPubDate.Name = "dtpPubDate"
        Me.dtpPubDate.Size = New System.Drawing.Size(139, 20)
        Me.dtpPubDate.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(22, 53)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "Title ID:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTitleId
        '
        Me.lblTitleId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTitleId.Location = New System.Drawing.Point(72, 50)
        Me.lblTitleId.Name = "lblTitleId"
        Me.lblTitleId.Size = New System.Drawing.Size(139, 20)
        Me.lblTitleId.TabIndex = 25
        Me.lblTitleId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtRoyalty
        '
        Me.txtRoyalty.Location = New System.Drawing.Point(314, 47)
        Me.txtRoyalty.Mask = "000000000000"
        Me.txtRoyalty.Name = "txtRoyalty"
        Me.txtRoyalty.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.txtRoyalty.Size = New System.Drawing.Size(139, 20)
        Me.txtRoyalty.TabIndex = 5
        Me.txtRoyalty.ValidatingType = GetType(Integer)
        '
        'txtYTDSales
        '
        Me.txtYTDSales.Location = New System.Drawing.Point(314, 80)
        Me.txtYTDSales.Mask = "00000"
        Me.txtYTDSales.Name = "txtYTDSales"
        Me.txtYTDSales.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.txtYTDSales.Size = New System.Drawing.Size(139, 20)
        Me.txtYTDSales.TabIndex = 6
        Me.txtYTDSales.ValidatingType = GetType(Integer)
        '
        'PublishersTableAdapter1
        '
        Me.PublishersTableAdapter1.ClearBeforeFill = True
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(72, 153)
        Me.txtPrice.MaxLength = 12
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(139, 20)
        Me.txtPrice.TabIndex = 3
        '
        'txtAdvance
        '
        Me.txtAdvance.Location = New System.Drawing.Point(72, 188)
        Me.txtAdvance.MaxLength = 12
        Me.txtAdvance.Name = "txtAdvance"
        Me.txtAdvance.Size = New System.Drawing.Size(139, 20)
        Me.txtAdvance.TabIndex = 4
        '
        'frmMaintenanceTitles
        '
        Me.AcceptButton = Me.btnAddTitle
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(483, 421)
        Me.Controls.Add(Me.txtAdvance)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtYTDSales)
        Me.Controls.Add(Me.txtRoyalty)
        Me.Controls.Add(Me.lblTitleId)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.dtpPubDate)
        Me.Controls.Add(Me.cboPublisherID)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.txtType)
        Me.Controls.Add(Me.txtTitle)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnAddTitle)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmMaintenanceTitles"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Maintenance - Titles"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents btnAddTitle As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtTitle As TextBox
    Friend WithEvents txtType As TextBox
    Friend WithEvents txtNotes As TextBox
    Friend WithEvents cboPublisherID As ComboBox
    Friend WithEvents dtpPubDate As DateTimePicker
    Friend WithEvents Label11 As Label
    Friend WithEvents lblTitleId As Label
    Friend WithEvents txtRoyalty As MaskedTextBox
    Friend WithEvents PublishersTableAdapter1 As BookStoreDO.BookStoreDataSetTableAdapters.publishersTableAdapter
    Friend WithEvents txtYTDSales As MaskedTextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents txtAdvance As TextBox
End Class
