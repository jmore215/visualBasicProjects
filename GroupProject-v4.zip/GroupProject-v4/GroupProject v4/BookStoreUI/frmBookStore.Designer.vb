﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBookStore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBookStore))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOder = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuShoppingCart = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaintenance = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaintTitles = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaintAuthor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMaintPublisher = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.SourceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MaintananceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuOder, Me.mnuMaintenance, Me.mnuReport, Me.SourceToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(493, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.mnuExit.Size = New System.Drawing.Size(136, 22)
        Me.mnuExit.Text = "Exit"
        '
        'mnuOder
        '
        Me.mnuOder.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuShoppingCart})
        Me.mnuOder.Name = "mnuOder"
        Me.mnuOder.Size = New System.Drawing.Size(49, 20)
        Me.mnuOder.Text = "Order"
        '
        'mnuShoppingCart
        '
        Me.mnuShoppingCart.Name = "mnuShoppingCart"
        Me.mnuShoppingCart.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuShoppingCart.Size = New System.Drawing.Size(190, 22)
        Me.mnuShoppingCart.Text = "Shopping Cart"
        '
        'mnuMaintenance
        '
        Me.mnuMaintenance.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMaintTitles, Me.mnuMaintAuthor, Me.mnuMaintPublisher})
        Me.mnuMaintenance.Name = "mnuMaintenance"
        Me.mnuMaintenance.Size = New System.Drawing.Size(88, 20)
        Me.mnuMaintenance.Text = "Maintenance"
        '
        'mnuMaintTitles
        '
        Me.mnuMaintTitles.Name = "mnuMaintTitles"
        Me.mnuMaintTitles.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.mnuMaintTitles.Size = New System.Drawing.Size(169, 22)
        Me.mnuMaintTitles.Text = "Titles"
        '
        'mnuMaintAuthor
        '
        Me.mnuMaintAuthor.Name = "mnuMaintAuthor"
        Me.mnuMaintAuthor.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnuMaintAuthor.Size = New System.Drawing.Size(169, 22)
        Me.mnuMaintAuthor.Text = "Authors"
        '
        'mnuMaintPublisher
        '
        Me.mnuMaintPublisher.Name = "mnuMaintPublisher"
        Me.mnuMaintPublisher.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.mnuMaintPublisher.Size = New System.Drawing.Size(169, 22)
        Me.mnuMaintPublisher.Text = "Publishers"
        '
        'mnuReport
        '
        Me.mnuReport.Name = "mnuReport"
        Me.mnuReport.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.mnuReport.Size = New System.Drawing.Size(54, 20)
        Me.mnuReport.Text = "Report"
        '
        'SourceToolStripMenuItem
        '
        Me.SourceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MaintananceToolStripMenuItem, Me.OrderToolStripMenuItem})
        Me.SourceToolStripMenuItem.Name = "SourceToolStripMenuItem"
        Me.SourceToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
        Me.SourceToolStripMenuItem.Text = "Source"
        '
        'MaintananceToolStripMenuItem
        '
        Me.MaintananceToolStripMenuItem.Name = "MaintananceToolStripMenuItem"
        Me.MaintananceToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.MaintananceToolStripMenuItem.Text = "Maintanance"
        '
        'OrderToolStripMenuItem
        '
        Me.OrderToolStripMenuItem.Name = "OrderToolStripMenuItem"
        Me.OrderToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.OrderToolStripMenuItem.Text = "Order"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(469, 301)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'frmBookStore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(493, 340)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmBookStore"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Book Store"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents mnuOder As ToolStripMenuItem
    Friend WithEvents mnuShoppingCart As ToolStripMenuItem
    Friend WithEvents mnuMaintenance As ToolStripMenuItem
    Friend WithEvents mnuMaintTitles As ToolStripMenuItem
    Friend WithEvents mnuMaintAuthor As ToolStripMenuItem
    Friend WithEvents mnuMaintPublisher As ToolStripMenuItem
    Friend WithEvents mnuReport As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents SourceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MaintananceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrderToolStripMenuItem As ToolStripMenuItem
End Class
