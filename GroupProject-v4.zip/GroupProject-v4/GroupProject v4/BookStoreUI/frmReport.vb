﻿'Affirmation of Authorship:

'Names: Andy Naranjo, Emmanuel Okafor, Denver Pomilban, Jennifer Moreno,

'Date: 07/27/2020

'I affirm that this program was created by us. It is solely our work and ‘does not include any work done by anyone else.

'Page created by....

Imports System.IO

Public Class frmReport
    Dim saleReports As New modReport
    Dim swSystemWriter As StreamWriter
    Dim strPath As String = ""

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnRSearch_Click(sender As Object, e As EventArgs) Handles btnRSearch.Click
        If lstReportItems.Items.Count = 0 Then
            saleReports.dateReport(dtpStartDate.Value.Date, dtpEndDate.Value.Date)
        Else
            lstReportItems.Items.Clear()
            saleReports.dateReport(dtpStartDate.Value.Date, dtpEndDate.Value.Date)
        End If

    End Sub

    Private Sub frmReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lstReportItems.Items.Clear()

        dtpEndDate.MaxDate = Today
        dtpStartDate.MaxDate = Today

        dtpStartDate.Value = Today
        dtpEndDate.Value = Today
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstReportItems.Items.Clear()
        dtpStartDate.Value = Today
        dtpEndDate.Value = Today
    End Sub

    Private Sub SFDCreate_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SFDCreate.FileOk

        Try
            If SFDCreate.FileName <> String.Empty Then
                swSystemWriter = New StreamWriter(SFDCreate.FileName, False)

                For index = 0 To lstReportItems.Items.Count - 1
                    swSystemWriter.WriteLine(lstReportItems.Items.Item(index).ToString)
                Next

                swSystemWriter.Close()
                Me.Close()
            Else
                MessageBox.Show("Please select a name for your file", "Warning")
            End If
        Catch ex As Exception
            MessageBox.Show("This Error Has Occured: " & ex.Message, "Error!")
        End Try

    End Sub

    Private Sub btnCreateFile_Click(sender As Object, e As EventArgs) Handles btnCreateFile.Click
        If lstReportItems.Items.Count > 0 Then
            SFDCreate.FileName = ""
            SFDCreate.ShowDialog()
        Else
            MessageBox.Show("Please do a search before trying to save the file", "Warning")
        End If

    End Sub
End Class