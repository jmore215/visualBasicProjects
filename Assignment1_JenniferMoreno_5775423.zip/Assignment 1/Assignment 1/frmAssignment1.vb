﻿'Affirmation of Authorship:
'Name: Jennifer Moreno
'Date: 5/19/20
'I affirm that this program was created by me. It is solely my work and
'does not include any work done by anyone else

Public Class frmAssignment1
    'Global variables for number 1, number 2, and operator
    Dim dblNumber1 As Double = 0.0
    Dim dblNumber2 As Double = 0.0
    Dim strOperation As String = String.Empty

    'Method for Addition Operator Button
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'Try to Parse txtInput.Text into Number1
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            strOperation = "+"
            dblNumber1 = txtInput.Text
            txtInput.Clear()
            txtInput.Focus()
        Else   'If unable to parse, then clear input and ask user to enter a number
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Subtraction Operator Button
    Private Sub btnSubtract_Click(sender As Object, e As EventArgs) Handles btnSubtract.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            strOperation = "-"
            dblNumber1 = txtInput.Text
            txtInput.Clear()
            txtInput.Focus()
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Multiplication Operator Button
    Private Sub btnMultiply_Click(sender As Object, e As EventArgs) Handles btnMultiply.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            strOperation = "*"
            dblNumber1 = txtInput.Text
            txtInput.Clear()
            txtInput.Focus()
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Exponent Operator Button
    Private Sub btnExponent_Click(sender As Object, e As EventArgs) Handles btnExponent.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            strOperation = "^"
            dblNumber1 = txtInput.Text
            txtInput.Clear()
            txtInput.Focus()
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Division Operator Button
    Private Sub btnDivide_Click(sender As Object, e As EventArgs) Handles btnDivide.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            strOperation = "/"
            dblNumber1 = txtInput.Text
            txtInput.Clear()
            txtInput.Focus()
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Modulus Operator Button
    Private Sub btnModulus_Click(sender As Object, e As EventArgs) Handles btnModulus.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            strOperation = "Mod"
            dblNumber1 = txtInput.Text
            txtInput.Clear()
            txtInput.Focus()
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Equals Button
    Private Sub btnEquals_Click(sender As Object, e As EventArgs) Handles btnEquals.Click
        'Create variables to show in the Equation and Result labels
        Dim calculation As String = String.Empty
        Dim result As Double = 0.0

        'Try to parse txtInput into Number2
        If Double.TryParse(txtInput.Text, dblNumber2) Then
            'Then check if input = 0 when dividing
            If txtInput.Text = 0 And strOperation = "/" Then
                MessageBox.Show("Cannot divide by 0.")
                txtInput.Clear()
            Else  'Otherwise, put input into Number2
                dblNumber2 = txtInput.Text
                txtInput.Clear()
            End If
            'If it can't be parsed, ask the user to enter a number
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If

        'Calculate the equation based on chosen operator
        Select Case strOperation
            Case "+"
                result = dblNumber1 + dblNumber2
            Case "-"
                result = dblNumber1 - dblNumber2
            Case "*"
                result = dblNumber1 * dblNumber2
            Case "^"
                result = dblNumber1 ^ dblNumber2
            Case "/"
                result = dblNumber1 / dblNumber2
            Case "Mod"
                result = dblNumber1 Mod dblNumber2
        End Select

        'Display this information into the Equation and Result labels
        calculation = CStr(dblNumber1) + " " + strOperation + " " + CStr(dblNumber2)
        lblEquation.Text = calculation
        lblResult.Text = result
    End Sub

    'Method for CE Button
    Private Sub btnCE_Click(sender As Object, e As EventArgs) Handles btnCE.Click
        txtInput.Clear()
    End Sub

    'Method for C Button
    Private Sub btnC_Click(sender As Object, e As EventArgs) Handles btnC.Click
        dblNumber1 = 0.0
        dblNumber2 = 0.0
        strOperation = String.Empty
        txtInput.Clear()
        lblEquation.Text = String.Empty
        lblResult.Text = String.Empty
    End Sub

    'Method for ± Button
    Private Sub btnPositiveNegative_Click(sender As Object, e As EventArgs) Handles btnPositiveNegative.Click
        If IsNumeric(txtInput.Text) Then
            txtInput.Text = txtInput.Text * (-1)
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for √ Button
    Private Sub btnSquareRoot_Click(sender As Object, e As EventArgs) Handles btnSquareRoot.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            lblEquation.Text = "√" + txtInput.Text
            lblResult.Text = Math.Sqrt(txtInput.Text)
            txtInput.Text = lblResult.Text
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Log Button
    Private Sub btnLog_Click(sender As Object, e As EventArgs) Handles btnLog.Click
        If Double.TryParse(txtInput.Text, dblNumber1) Then
            lblEquation.Text = "Log " + txtInput.Text
            lblResult.Text = Math.Log(txtInput.Text)
            txtInput.Text = lblResult.Text
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Please enter a number.")
        End If
    End Sub

    'Method for Exit Button
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    'Method for MC Button
    Private Sub btnMC_Click(sender As Object, e As EventArgs) Handles btnMC.Click
        lblMemory.Text = 0
    End Sub

    'Method for MR Button
    Private Sub btnMR_Click(sender As Object, e As EventArgs) Handles btnMR.Click
        txtInput.Text = lblMemory.Text
    End Sub

    'Method for MS Button
    Private Sub btnMS_Click(sender As Object, e As EventArgs) Handles btnMS.Click
        'Check to ensure only numbers go into memory
        If IsNumeric(txtInput.Text) Then
            lblMemory.Text = txtInput.Text
        Else
            txtInput.Clear()
            txtInput.Focus()
            MessageBox.Show("Only a number can be saved.")
        End If
    End Sub

    'Method for Form Loading
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Clear labels when loading form
        lblMemory.Text = String.Empty
        lblEquation.Text = String.Empty
        lblResult.Text = String.Empty
    End Sub
End Class
