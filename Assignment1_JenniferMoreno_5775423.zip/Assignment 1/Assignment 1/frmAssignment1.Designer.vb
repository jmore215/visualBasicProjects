﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAssignment1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAssignment1))
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.lblMemory = New System.Windows.Forms.Label()
        Me.lblEquation = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnExponent = New System.Windows.Forms.Button()
        Me.btnPositiveNegative = New System.Windows.Forms.Button()
        Me.btnCE = New System.Windows.Forms.Button()
        Me.btnMC = New System.Windows.Forms.Button()
        Me.btnSubtract = New System.Windows.Forms.Button()
        Me.btnDivide = New System.Windows.Forms.Button()
        Me.btnSquareRoot = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnMR = New System.Windows.Forms.Button()
        Me.btnMultiply = New System.Windows.Forms.Button()
        Me.btnModulus = New System.Windows.Forms.Button()
        Me.btnLog = New System.Windows.Forms.Button()
        Me.btnEquals = New System.Windows.Forms.Button()
        Me.btnMS = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(77, 22)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(155, 20)
        Me.txtInput.TabIndex = 0
        '
        'lblMemory
        '
        Me.lblMemory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMemory.Location = New System.Drawing.Point(77, 267)
        Me.lblMemory.Name = "lblMemory"
        Me.lblMemory.Size = New System.Drawing.Size(155, 23)
        Me.lblMemory.TabIndex = 1
        Me.lblMemory.Text = "lblMemory"
        '
        'lblEquation
        '
        Me.lblEquation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEquation.Location = New System.Drawing.Point(77, 298)
        Me.lblEquation.Name = "lblEquation"
        Me.lblEquation.Size = New System.Drawing.Size(155, 23)
        Me.lblEquation.TabIndex = 2
        Me.lblEquation.Text = "lblEquation"
        '
        'lblResult
        '
        Me.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResult.Location = New System.Drawing.Point(77, 332)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(155, 23)
        Me.lblResult.TabIndex = 3
        Me.lblResult.Text = "lblResult"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 267)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Memory:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 298)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Equation:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(34, 332)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Result:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(40, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Input:"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(79, 57)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(47, 32)
        Me.btnAdd.TabIndex = 8
        Me.btnAdd.Text = "+"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnExponent
        '
        Me.btnExponent.Location = New System.Drawing.Point(79, 95)
        Me.btnExponent.Name = "btnExponent"
        Me.btnExponent.Size = New System.Drawing.Size(47, 32)
        Me.btnExponent.TabIndex = 9
        Me.btnExponent.Text = "^"
        Me.btnExponent.UseVisualStyleBackColor = True
        '
        'btnPositiveNegative
        '
        Me.btnPositiveNegative.Location = New System.Drawing.Point(79, 133)
        Me.btnPositiveNegative.Name = "btnPositiveNegative"
        Me.btnPositiveNegative.Size = New System.Drawing.Size(47, 34)
        Me.btnPositiveNegative.TabIndex = 10
        Me.btnPositiveNegative.Text = "±"
        Me.btnPositiveNegative.UseVisualStyleBackColor = True
        '
        'btnCE
        '
        Me.btnCE.Location = New System.Drawing.Point(79, 173)
        Me.btnCE.Name = "btnCE"
        Me.btnCE.Size = New System.Drawing.Size(47, 33)
        Me.btnCE.TabIndex = 11
        Me.btnCE.Text = "CE"
        Me.btnCE.UseVisualStyleBackColor = True
        '
        'btnMC
        '
        Me.btnMC.Location = New System.Drawing.Point(79, 222)
        Me.btnMC.Name = "btnMC"
        Me.btnMC.Size = New System.Drawing.Size(47, 34)
        Me.btnMC.TabIndex = 12
        Me.btnMC.Text = "MC"
        Me.btnMC.UseVisualStyleBackColor = True
        '
        'btnSubtract
        '
        Me.btnSubtract.Location = New System.Drawing.Point(132, 57)
        Me.btnSubtract.Name = "btnSubtract"
        Me.btnSubtract.Size = New System.Drawing.Size(47, 32)
        Me.btnSubtract.TabIndex = 13
        Me.btnSubtract.Text = "-"
        Me.btnSubtract.UseVisualStyleBackColor = True
        '
        'btnDivide
        '
        Me.btnDivide.Location = New System.Drawing.Point(132, 95)
        Me.btnDivide.Name = "btnDivide"
        Me.btnDivide.Size = New System.Drawing.Size(47, 32)
        Me.btnDivide.TabIndex = 14
        Me.btnDivide.Text = "/"
        Me.btnDivide.UseVisualStyleBackColor = True
        '
        'btnSquareRoot
        '
        Me.btnSquareRoot.Location = New System.Drawing.Point(132, 133)
        Me.btnSquareRoot.Name = "btnSquareRoot"
        Me.btnSquareRoot.Size = New System.Drawing.Size(47, 34)
        Me.btnSquareRoot.TabIndex = 15
        Me.btnSquareRoot.Text = "√"
        Me.btnSquareRoot.UseVisualStyleBackColor = True
        '
        'btnC
        '
        Me.btnC.Location = New System.Drawing.Point(132, 173)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(47, 33)
        Me.btnC.TabIndex = 16
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'btnMR
        '
        Me.btnMR.Location = New System.Drawing.Point(132, 222)
        Me.btnMR.Name = "btnMR"
        Me.btnMR.Size = New System.Drawing.Size(47, 34)
        Me.btnMR.TabIndex = 17
        Me.btnMR.Text = "MR"
        Me.btnMR.UseVisualStyleBackColor = True
        '
        'btnMultiply
        '
        Me.btnMultiply.Location = New System.Drawing.Point(185, 57)
        Me.btnMultiply.Name = "btnMultiply"
        Me.btnMultiply.Size = New System.Drawing.Size(48, 32)
        Me.btnMultiply.TabIndex = 18
        Me.btnMultiply.Text = "*"
        Me.btnMultiply.UseVisualStyleBackColor = True
        '
        'btnModulus
        '
        Me.btnModulus.Location = New System.Drawing.Point(185, 95)
        Me.btnModulus.Name = "btnModulus"
        Me.btnModulus.Size = New System.Drawing.Size(48, 32)
        Me.btnModulus.TabIndex = 19
        Me.btnModulus.Text = "Mod"
        Me.btnModulus.UseVisualStyleBackColor = True
        '
        'btnLog
        '
        Me.btnLog.Location = New System.Drawing.Point(185, 133)
        Me.btnLog.Name = "btnLog"
        Me.btnLog.Size = New System.Drawing.Size(47, 34)
        Me.btnLog.TabIndex = 20
        Me.btnLog.Text = "Log"
        Me.btnLog.UseVisualStyleBackColor = True
        '
        'btnEquals
        '
        Me.btnEquals.Location = New System.Drawing.Point(185, 173)
        Me.btnEquals.Name = "btnEquals"
        Me.btnEquals.Size = New System.Drawing.Size(48, 33)
        Me.btnEquals.TabIndex = 21
        Me.btnEquals.Text = "="
        Me.btnEquals.UseVisualStyleBackColor = True
        '
        'btnMS
        '
        Me.btnMS.Location = New System.Drawing.Point(185, 222)
        Me.btnMS.Name = "btnMS"
        Me.btnMS.Size = New System.Drawing.Size(48, 34)
        Me.btnMS.TabIndex = 22
        Me.btnMS.Text = "MS"
        Me.btnMS.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(77, 366)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(156, 23)
        Me.btnExit.TabIndex = 23
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmAssignment1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(272, 400)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnMS)
        Me.Controls.Add(Me.btnEquals)
        Me.Controls.Add(Me.btnLog)
        Me.Controls.Add(Me.btnModulus)
        Me.Controls.Add(Me.btnMultiply)
        Me.Controls.Add(Me.btnMR)
        Me.Controls.Add(Me.btnC)
        Me.Controls.Add(Me.btnSquareRoot)
        Me.Controls.Add(Me.btnDivide)
        Me.Controls.Add(Me.btnSubtract)
        Me.Controls.Add(Me.btnMC)
        Me.Controls.Add(Me.btnCE)
        Me.Controls.Add(Me.btnPositiveNegative)
        Me.Controls.Add(Me.btnExponent)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.lblEquation)
        Me.Controls.Add(Me.lblMemory)
        Me.Controls.Add(Me.txtInput)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAssignment1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtInput As TextBox
    Friend WithEvents lblMemory As Label
    Friend WithEvents lblEquation As Label
    Friend WithEvents lblResult As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnExponent As Button
    Friend WithEvents btnPositiveNegative As Button
    Friend WithEvents btnCE As Button
    Friend WithEvents btnMC As Button
    Friend WithEvents btnSubtract As Button
    Friend WithEvents btnDivide As Button
    Friend WithEvents btnSquareRoot As Button
    Friend WithEvents btnC As Button
    Friend WithEvents btnMR As Button
    Friend WithEvents btnMultiply As Button
    Friend WithEvents btnModulus As Button
    Friend WithEvents btnLog As Button
    Friend WithEvents btnEquals As Button
    Friend WithEvents btnMS As Button
    Friend WithEvents btnExit As Button
End Class
